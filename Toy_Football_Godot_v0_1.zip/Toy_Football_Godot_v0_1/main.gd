extends Node3D

# Toy Football v0.1: two people, one phone, simultaneous touch controls.
const FIELD_X := 8.0
const FIELD_Z := 4.15
const GOAL_Z := 1.25
const ROUND_SECONDS := 120.0
const FIGURE_SPEED := 9.5
const BALL_FRICTION := 1.5
const KICK_POWER := 12.8
const ZONE_RADIUS := 2.35

var camera: Camera3D
var ball: Node3D
var ball_pos := Vector2.ZERO
var ball_vel := Vector2.ZERO
var players: Array[Dictionary] = []
var clock := ROUND_SECONDS
var scores := [0, 0]
var playing := false
var finished := false
var reset_delay := 0.0
var hud: Label
var banner: Label
var hint: Label
var flash: Label
var flash_time := 0.0
var touch_fingers := {}
var mat_cache := {}

func material(color: Color, metallic: float = 0.0) -> StandardMaterial3D:
    var key := "%s_%.1f" % [color.to_html(), metallic]
    if mat_cache.has(key):
        return mat_cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = 0.38
    mat_cache[key] = m
    return m

func box_mesh(parent: Node3D, name: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.material_override = material(color)
    n.position = pos
    parent.add_child(n)
    return n

func sphere_mesh(parent: Node3D, name: String, pos: Vector3, radius: float, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 12
    mesh.rings = 6
    n.mesh = mesh
    n.material_override = material(color)
    n.position = pos
    parent.add_child(n)
    return n

func cylinder_mesh(parent: Node3D, name: String, pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius * 1.12
    mesh.height = height
    mesh.radial_segments = 16
    n.mesh = mesh
    n.material_override = material(color)
    n.position = pos
    parent.add_child(n)
    return n

func _ready() -> void:
    _make_scene()
    _make_ui()
    _reset_positions()
    _show_menu("TOY FOOTBALL", "ДВА ИГРОКА • ОДИН ТЕЛЕФОН\nКАСАЙТЕСЬ СВОИХ ИГРУШЕК, ЧТОБЫ БИТЬ ПО МЯЧУ\n\nНАЖМИТЕ НА ЭКРАН ДЛЯ СТАРТА")

func _make_scene() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 15.6, 10.8)
    camera.look_at(Vector3.ZERO, Vector3.UP)
    camera.projection = Camera3D.PROJECTION_ORTHOGONAL
    camera.size = 21.7
    camera.current = true
    add_child(camera)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55, -20, 0)
    light.light_energy = 1.7
    add_child(light)
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#142337")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#cce4ff")
    e.ambient_light_energy = 0.8
    env.environment = e
    add_child(env)

    box_mesh(self, "ToyTable", Vector3(0,-0.48,0), Vector3(18.3,0.9,10.3), Color("#28394b"))
    box_mesh(self, "Pitch", Vector3(0,0,0), Vector3(16.0,0.12,8.3), Color("#36a968"))
    for i in range(8):
        box_mesh(self, "Stripe", Vector3(-7.0 + i*2.0,0.067,0), Vector3(1.0,0.012,8.15), Color("#309d61"))
    var white := Color("#e8f9ee")
    box_mesh(self, "MidLine", Vector3(0,0.08,0), Vector3(0.055,0.015,8.15), white)
    for side in [-1,1]:
        box_mesh(self, "BoxEnd", Vector3(side*6.25,0.08,0), Vector3(0.055,0.015,3.8), white)
        for zz in [-1.9,1.9]:
            box_mesh(self, "BoxSide", Vector3(side*7.12,0.08,zz), Vector3(1.75,0.015,0.055), white)
        box_mesh(self, "GoalBack", Vector3(side*8.55,0.37,0), Vector3(0.12,0.75,2.75), Color("#f4f0d6"))
        for zz in [-1.4,1.4]:
            box_mesh(self, "GoalPost", Vector3(side*8.15,0.4,zz), Vector3(0.8,0.8,0.10), white)
    for zz in [-4.22,4.22]:
        box_mesh(self, "Wall", Vector3(0,0.27,zz), Vector3(17.2,0.55,0.18), Color("#9ec3c8"))
    for side in [-1,1]:
        for zz in [-3.2,3.2]:
            box_mesh(self, "Corner", Vector3(side*8.2,0.26,zz), Vector3(0.25,0.52,1.65), Color("#a8b9c9"))
    cylinder_mesh(self, "CentreRing", Vector3(0,0.078,0), 1.03,0.02, Color("#55ba79"))
    cylinder_mesh(self, "CentreDot", Vector3(0,0.095,0), 0.10,0.02, white)
    ball = Node3D.new()
    ball.name = "Ball"
    add_child(ball)
    sphere_mesh(ball,"WhiteBall",Vector3(0,0.35,0),0.34,Color("#f6f4e9"))
    for i in range(5):
        var a := i * TAU / 5.0
        sphere_mesh(ball,"Patch",Vector3(cos(a)*0.29,0.37,sin(a)*0.29),0.105,Color("#303c4c"))
    for team in range(2):
        var side := -1.0 if team == 0 else 1.0
        var coords := [Vector2(side*6.3,0),Vector2(side*3.4,-2.2),Vector2(side*3.4,2.2)]
        for i in range(3):
            var anchor: Vector2 = coords[i]
            var root := Node3D.new()
            root.name = "BlueToy%d" % i if team == 0 else "RedToy%d" % i
            add_child(root)
            var color := Color("#278bf0") if team == 0 else Color("#f25c56")
            cylinder_mesh(root,"Base",Vector3(0,0.14,0),0.52,0.28,Color("#e9d8b2"))
            cylinder_mesh(root,"Body",Vector3(0,0.68,0),0.34,0.77,color)
            sphere_mesh(root,"Head",Vector3(0,1.27,0),0.35,Color("#ffe1b6"))
            sphere_mesh(root,"LeftEye",Vector3(-0.12,1.34,-0.30),0.055,Color("#253041"))
            sphere_mesh(root,"RightEye",Vector3(0.12,1.34,-0.30),0.055,Color("#253041"))
            box_mesh(root,"Cap",Vector3(0,1.58,0),Vector3(0.72,0.15,0.73),color)
            sphere_mesh(root,"FootL",Vector3(-0.24,0.31,-0.22),0.16,Color("#344c69"))
            sphere_mesh(root,"FootR",Vector3(0.24,0.31,-0.22),0.16,Color("#344c69"))
            root.position = Vector3(anchor.x,0,anchor.y)
            players.append({"node":root,"team":team,"home":anchor,"pos":anchor,"target":anchor,"dash":false,"cooldown":0.0})

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var ui := Control.new()
    ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(ui)
    hud = Label.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    hud.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud.add_theme_font_size_override("font_size", 35)
    hud.add_theme_color_override("font_color",Color.WHITE)
    hud.position.y = 8
    ui.add_child(hud)
    banner = Label.new()
    banner.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    banner.add_theme_font_size_override("font_size", 56)
    banner.add_theme_color_override("font_color",Color("#fff1aa"))
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(banner)
    hint = Label.new()
    hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 22)
    hint.add_theme_color_override("font_color",Color.WHITE)
    hint.position.y = -38
    hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(hint)
    flash = Label.new()
    flash.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    flash.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    flash.add_theme_font_size_override("font_size", 55)
    flash.add_theme_color_override("font_color",Color("#ffe166"))
    flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(flash)

func _show_menu(title: String, subtitle: String) -> void:
    banner.text = title
    hint.text = subtitle
    hud.text = "СИНИЕ %d : %d КРАСНЫЕ" % [scores[0],scores[1]]

func _reset_positions() -> void:
    ball_pos = Vector2.ZERO
    ball_vel = Vector2.ZERO
    ball.position = Vector3.ZERO
    for p in players:
        p["pos"] = p["home"]
        p["target"] = p["home"]
        p["dash"] = false
        p["cooldown"] = 0.0
        var point: Vector2 = p["pos"]
        (p["node"] as Node3D).position = Vector3(point.x,0,point.y)

func _start() -> void:
    scores = [0,0]
    clock = ROUND_SECONDS
    reset_delay = 0.0
    finished = false
    playing = true
    banner.text = ""
    hint.text = "СИНИЕ: ЛЕВАЯ СТОРОНА      •      КРАСНЫЕ: ПРАВАЯ СТОРОНА"
    _reset_positions()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        _handle_press(event.position, event.index)
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        _handle_press(event.position, -1)

func _handle_press(screen: Vector2, finger: int) -> void:
    if not playing:
        _start()
        return
    if reset_delay > 0.0:
        return
    var viewport_size := get_viewport().get_visible_rect().size
    var team := 0 if screen.x < viewport_size.x * 0.5 else 1
    var chosen := -1
    var best := 115.0 * viewport_size.x / 1280.0
    for i in range(players.size()):
        var p: Dictionary = players[i]
        if p["team"] != team:
            continue
        var world: Vector2 = p["pos"]
        var projected := camera.unproject_position(Vector3(world.x,0.8,world.y))
        var distance := screen.distance_to(projected)
        if distance < best:
            best = distance
            chosen = i
    if chosen >= 0:
        var p: Dictionary = players[chosen]
        if p["cooldown"] <= 0.0:
            p["dash"] = true
            p["cooldown"] = 0.45
            touch_fingers[finger] = chosen

func _physics_process(delta: float) -> void:
    if flash_time > 0.0:
        flash_time -= delta
        if flash_time <= 0.0:
            flash.text = ""
    if not playing:
        return
    if reset_delay > 0.0:
        reset_delay -= delta
        if reset_delay <= 0.0:
            _reset_positions()
        return
    clock -= delta
    if clock <= 0.0:
        playing = false
        finished = true
        var result := "НИЧЬЯ!" if scores[0] == scores[1] else ("ПОБЕДА СИНИХ!" if scores[0] > scores[1] else "ПОБЕДА КРАСНЫХ!")
        _show_menu(result, "НАЖМИТЕ НА ЭКРАН — ЕЩЁ МАТЧ")
        return
    var seconds := int(ceil(clock))
    hud.text = "🔵 %d : %d 🔴        %02d:%02d" % [scores[0],scores[1],seconds/60,seconds%60]
    for p in players:
        p["cooldown"] = maxf(0.0,p["cooldown"] - delta)
        var home: Vector2 = p["home"]
        var pos: Vector2 = p["pos"]
        var target: Vector2 = home
        if p["dash"]:
            target = home + (ball_pos-home).limit_length(ZONE_RADIUS)
        pos = pos.move_toward(target,FIGURE_SPEED * delta if p["dash"] else FIGURE_SPEED*0.55*delta)
        p["pos"] = pos
        (p["node"] as Node3D).position = Vector3(pos.x,0,pos.y)
        if p["dash"] and pos.distance_to(ball_pos) < 0.83:
            var direction := Vector2(1,0) if p["team"] == 0 else Vector2(-1,0)
            direction = (direction*1.8 + (ball_pos-pos).normalized()*0.5).normalized()
            ball_vel = direction*KICK_POWER
            p["dash"] = false
            _flash("УДАР!")
        elif p["dash"] and pos.distance_to(target) < 0.06:
            p["dash"] = false
        if pos.distance_to(ball_pos) < 0.57 and ball_vel.length() > 0.5:
            ball_vel = (ball_pos-pos).normalized()*maxf(ball_vel.length()*0.8,2.0)
    ball_pos += ball_vel * delta
    ball_vel = ball_vel.move_toward(Vector2.ZERO, BALL_FRICTION*delta)
    if absf(ball_pos.y) > FIELD_Z-0.35:
        ball_pos.y = signf(ball_pos.y)*(FIELD_Z-0.35)
        ball_vel.y *= -0.82
    if absf(ball_pos.x) > FIELD_X:
        if absf(ball_pos.y) < GOAL_Z:
            var scorer := 0 if ball_pos.x > 0 else 1
            scores[scorer] += 1
            _flash("ГОООЛ!")
            reset_delay = 1.8
            ball_vel = Vector2.ZERO
        else:
            ball_pos.x = signf(ball_pos.x)*FIELD_X
            ball_vel.x *= -0.83
    ball.position = Vector3(ball_pos.x,0,ball_pos.y)
    ball.rotate_y(ball_vel.length()*delta*0.8)

func _flash(message: String) -> void:
    flash.text = message
    flash_time = 0.6 if message == "УДАР!" else 1.7
