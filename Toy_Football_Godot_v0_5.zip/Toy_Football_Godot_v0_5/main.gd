extends Node2D
# Arcade tabletop football. Drag a figurine to steer it. Ball is kicked on contact.
const W := 1280.0
const H := 720.0
const LEFT := 82.0
const RIGHT := 1198.0
const TOP := 142.0
const BOTTOM := 632.0
const MID := 640.0
const GOAL_TOP := 322.0
const GOAL_BOTTOM := 452.0
const RADIUS := 22.0
const BALL_R := 12.0
const SPEED := 320.0
const KICK := 730.0
var font: Font
var phase := 0 # menu, play, result
var opponent := 0 # 0 bot, 1 human
var rule := 0 # 0 4 min, 1 first to 10
var score_blue := 0
var score_red := 0
var seconds := 240.0
var message := ""
var ball := Vector2(MID, 387)
var velocity := Vector2.ZERO
var players: Array[Dictionary] = []
var touches: Dictionary = {} # touch id -> {team, player, target}
var bot_retarget := 0.0
var kick_cool := 0.0
var goal_pause := 0.0
var match_time := 0.0

func _ready() -> void:
    font = ThemeDB.fallback_font
    _reset_positions()

func _reset_positions() -> void:
    players.clear()
    touches.clear()
    var slots := [Vector2(155,387),Vector2(325,387),Vector2(490,270),Vector2(490,510)]
    for team in range(2):
        for j in range(4):
            var pos: Vector2 = slots[j]
            if team == 1:
                pos.x = W - pos.x
            players.append({"pos":pos,"team":team,"role":j,"target":pos,"controlled":false,"face":Vector2(1 if team == 0 else -1,0),"cool":0.0})
    ball = Vector2(MID,387)
    velocity = Vector2.ZERO
    kick_cool = 0.0
    bot_retarget = 0.0

func _start_game() -> void:
    score_blue = 0
    score_red = 0
    seconds = 240.0
    match_time = 0.0
    message = ""
    phase = 1
    goal_pause = 0.0
    _reset_positions()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _touch_down(event.index,event.position)
        else:
            touches.erase(event.index)
    elif event is InputEventScreenDrag:
        _touch_move(event.index,event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _touch_down(99,event.position)
        else:
            touches.erase(99)
    elif event is InputEventMouseMotion and touches.has(99):
        _touch_move(99,event.position)

func _touch_down(id: int, pos: Vector2) -> void:
    if phase == 0:
        if Rect2(340,256,600,78).has_point(pos):
            opponent = 1 - opponent
        elif Rect2(340,349,600,78).has_point(pos):
            rule = 1 - rule
        elif Rect2(340,452,600,92).has_point(pos):
            _start_game()
        return
    if phase == 2:
        phase = 0
        return
    if goal_pause > 0.0:
        return
    # Human players can take control of ANY figurine in their team, including goalkeeper.
    var team := 0
    if opponent == 1 and pos.x > MID:
        team = 1
    var chosen := -1
    var nearest := 150.0
    for i in range(players.size()):
        if int(players[i]["team"]) != team:
            continue
        var taken := false
        for touch in touches.values():
            if int(touch["player"]) == i:
                taken = true
        if taken:
            continue
        var dist: float = (players[i]["pos"] as Vector2).distance_to(pos)
        if dist < nearest:
            nearest = dist
            chosen = i
    # If touched an empty part of the field, pick the closest non-goalkeeper.
    if chosen == -1:
        nearest = INF
        for i in range(players.size()):
            if int(players[i]["team"]) != team or int(players[i]["role"]) == 0:
                continue
            var dist: float = (players[i]["pos"] as Vector2).distance_to(pos)
            if dist < nearest:
                nearest = dist
                chosen = i
    if chosen >= 0:
        touches[id] = {"player":chosen,"target":pos}
        players[chosen]["controlled"] = true

func _touch_move(id: int, pos: Vector2) -> void:
    if touches.has(id):
        touches[id]["target"] = pos

func _process(dt: float) -> void:
    if phase != 1:
        queue_redraw()
        return
    if goal_pause > 0.0:
        goal_pause -= dt
        if goal_pause <= 0.0:
            _reset_positions()
        queue_redraw()
        return
    match_time += dt
    if rule == 0:
        seconds = maxf(0.0,seconds-dt)
        if seconds <= 0.0:
            _finish()
            return
    kick_cool = maxf(0.0,kick_cool-dt)
    bot_retarget -= dt
    for i in range(players.size()):
        var p: Dictionary = players[i]
        var team: int = p["team"]
        var role: int = p["role"]
        var current: Vector2 = p["pos"]
        var target: Vector2 = p["target"]
        var is_controlled := false
        for touch in touches.values():
            if int(touch["player"]) == i:
                target = touch["target"]
                is_controlled = true
        if not is_controlled:
            if team == 1 and opponent == 0:
                # Bot moves one closest field player to the ball; others guard lanes.
                if role == 0:
                    target = Vector2(W - 155.0, clampf(ball.y,GOAL_TOP+28,GOAL_BOTTOM-28))
                else:
                    var nearest_bot := _closest_to_ball(1)
                    if nearest_bot == i:
                        target = ball + Vector2(18,0)
                    else:
                        var home: Vector2 = _home(i)
                        target = home + Vector2(clampf(ball.x-MID,-130,130)*0.24,clampf(ball.y-home.y,-110,110)*0.24)
            else:
                # Idle human team figures drift gently into formation, never kick on their own.
                target = _home(i)
        if role == 0:
            target.x = 155.0 if team == 0 else W-155.0
            target.y = clampf(target.y,GOAL_TOP+25,GOAL_BOTTOM-25)
        else:
            target.x = clampf(target.x,LEFT+RADIUS,RIGHT-RADIUS)
            target.y = clampf(target.y,TOP+RADIUS,BOTTOM-RADIUS)
        var speed := SPEED
        if role == 0:
            speed = 205.0
        if team == 1 and opponent == 0:
            speed *= 0.78
        var step: Vector2 = (target-current).limit_length(speed*dt)
        p["pos"] = current+step
        if step.length() > 0.5:
            p["face"] = step.normalized()
        p["controlled"] = is_controlled
        players[i] = p
        # A player kicks when the ball actually comes within reach.
        if kick_cool <= 0.0 and (ball-(p["pos"] as Vector2)).length() < RADIUS+BALL_R+8:
            var direction: Vector2 = p["face"]
            if team == 1 and opponent == 0:
                direction = Vector2(-1,clampf((387-ball.y)/280,-0.35,0.35)).normalized()
            elif is_controlled:
                var v: Vector2 = target-(p["pos"] as Vector2)
                if v.length() > 12:
                    direction = v.normalized()
            else:
                # Uncontrolled players only deflect, no accurate automatic shots.
                direction = (ball-(p["pos"] as Vector2)).normalized()
            if direction.length() < 0.5:
                direction = Vector2(1 if team == 0 else -1,0)
            velocity = direction*KICK
            ball = (p["pos"] as Vector2)+direction*(RADIUS+BALL_R+9)
            kick_cool = 0.24
    ball += velocity*dt
    velocity *= pow(0.985,dt*60.0)
    if absf(velocity.x) < 4 and absf(velocity.y) < 4:
        velocity = Vector2.ZERO
    if ball.y < TOP+BALL_R:
        ball.y = TOP+BALL_R
        velocity.y = absf(velocity.y)*0.82
    if ball.y > BOTTOM-BALL_R:
        ball.y = BOTTOM-BALL_R
        velocity.y = -absf(velocity.y)*0.82
    if ball.x < LEFT+BALL_R:
        if ball.y > GOAL_TOP and ball.y < GOAL_BOTTOM:
            _goal(1)
        else:
            ball.x = LEFT+BALL_R
            velocity.x = absf(velocity.x)*0.8
    if ball.x > RIGHT-BALL_R:
        if ball.y > GOAL_TOP and ball.y < GOAL_BOTTOM:
            _goal(0)
        else:
            ball.x = RIGHT-BALL_R
            velocity.x = -absf(velocity.x)*0.8
    queue_redraw()

func _home(i: int) -> Vector2:
    var role := i%4
    var positions := [Vector2(155,387),Vector2(325,387),Vector2(490,270),Vector2(490,510)]
    var home: Vector2 = positions[role]
    if i >= 4:
        home.x = W-home.x
    return home

func _closest_to_ball(team: int) -> int:
    var best := INF
    var chosen := -1
    for i in range(players.size()):
        if int(players[i]["team"]) != team or int(players[i]["role"]) == 0:
            continue
        var dist: float = (players[i]["pos"] as Vector2).distance_to(ball)
        if dist < best:
            best = dist
            chosen = i
    return chosen

func _goal(team: int) -> void:
    if team == 0:
        score_blue += 1
        message = "ГОЛ СИНИХ!"
    else:
        score_red += 1
        message = "ГОЛ КРАСНЫХ!"
    goal_pause = 1.3
    velocity = Vector2.ZERO
    touches.clear()
    if rule == 1 and (score_blue >= 10 or score_red >= 10):
        _finish()

func _finish() -> void:
    phase = 2
    touches.clear()
    if score_blue > score_red:
        message = "ПОБЕДА СИНИХ!"
    elif score_red > score_blue:
        message = "ПОБЕДА КРАСНЫХ!"
    else:
        message = "НИЧЬЯ!"

func _label(s: String, at: Vector2, size: int = 26, color: Color = Color.WHITE) -> void:
    draw_string(font,at,s,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _center(s: String, x: float, y: float, size: int = 28, color: Color = Color.WHITE) -> void:
    var width := font.get_string_size(s,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
    _label(s,Vector2(x-width*0.5,y),size,color)

func _button(rect: Rect2, text_value: String, color: Color) -> void:
    draw_rect(rect,Color(0.05,0.12,0.23),true)
    draw_rect(rect,color,false,4.0)
    _center(text_value,rect.position.x+rect.size.x*0.5,rect.position.y+rect.size.y*0.62,30)

func _draw() -> void:
    draw_rect(Rect2(0,0,W,H),Color("101c32"),true)
    if phase == 0:
        _center("TOY FOOTBALL",MID,156,66,Color("f5d47c"))
        _center("АРКАДНЫЙ НАСТОЛЬНЫЙ ФУТБОЛ",MID,205,24,Color("b4d4e9"))
        _button(Rect2(340,256,600,78),"СОПЕРНИК: " + ("БОТ" if opponent == 0 else "2 ИГРОКА"),Color("54b5ff"))
        _button(Rect2(340,349,600,78),"МАТЧ: " + ("4 МИНУТЫ" if rule == 0 else "ДО 10 ГОЛОВ"),Color("54b5ff"))
        _button(Rect2(340,452,600,92),"ИГРАТЬ",Color("f4d377"))
        _center("ТЯНИ ФИГУРКУ ПАЛЬЦЕМ — ОНА БЕЖИТ И БЬЁТ ПО МЯЧУ",MID,615,23,Color("bed0e5"))
        return
    _center("СИНИЕ  %d : %d  КРАСНЫЕ" % [score_blue,score_red],MID,54,34)
    if rule == 0:
        var secs := int(ceil(seconds))
        _center("%02d:%02d" % [int(secs/60.0),secs%60],MID,90,26,Color("f3d989"))
    else:
        _center("ПЕРВЫЙ ДО 10",MID,90,26,Color("f3d989"))
    # Field and goal mouths.
    draw_rect(Rect2(LEFT-16,TOP-17,RIGHT-LEFT+32,BOTTOM-TOP+34),Color("45576c"),true)
    draw_rect(Rect2(LEFT,TOP,RIGHT-LEFT,BOTTOM-TOP),Color("23885d"),true)
    for n in range(8):
        if n%2 == 0:
            draw_rect(Rect2(LEFT+n*(RIGHT-LEFT)/8.0,TOP,(RIGHT-LEFT)/8.0,BOTTOM-TOP),Color(1,1,1,0.035),true)
    draw_rect(Rect2(LEFT,TOP,RIGHT-LEFT,BOTTOM-TOP),Color("e8fff1"),false,4)
    draw_line(Vector2(MID,TOP),Vector2(MID,BOTTOM),Color("e8fff1"),3)
    draw_arc(Vector2(MID,387),76,0,TAU,80,Color("e8fff1"),3)
    draw_rect(Rect2(LEFT,277,158,220),Color("e8fff1"),false,3)
    draw_rect(Rect2(RIGHT-158,277,158,220),Color("e8fff1"),false,3)
    draw_rect(Rect2(LEFT-29,GOAL_TOP,29,GOAL_BOTTOM-GOAL_TOP),Color("b9d8ff"),true)
    draw_rect(Rect2(RIGHT,GOAL_TOP,29,GOAL_BOTTOM-GOAL_TOP),Color("b9d8ff"),true)
    # Small gaps behind goalkeepers make scoring possible.
    for p in players:
        var pos: Vector2 = p["pos"]
        var team: int = p["team"]
        var color := Color("36b0ff") if team == 0 else Color("ff6265")
        draw_circle(pos+Vector2(3,7),RADIUS+5,Color(0,0,0,0.3))
        draw_circle(pos,RADIUS+4,Color("d8c8a0"))
        draw_circle(pos,RADIUS,color)
        draw_circle(pos+Vector2(-5,-6),7,Color("ffe5b5"))
        draw_circle(pos+Vector2(-7,-7),1.6,Color("1b2742"))
        draw_circle(pos+Vector2(-3,-7),1.6,Color("1b2742"))
        if int(p["role"]) == 0:
            draw_arc(pos,RADIUS+7,0,TAU,24,Color("fff4a3"),3)
        if p["controlled"]:
            draw_arc(pos,RADIUS+11,0,TAU,32,Color.WHITE,3)
    draw_circle(ball+Vector2(2,4),BALL_R+1,Color(0,0,0,0.3))
    draw_circle(ball,BALL_R,Color.WHITE)
    draw_circle(ball,4,Color("263b54"))
    if phase == 2:
        draw_rect(Rect2(0,0,W,H),Color(0,0,0,0.68),true)
        _center(message,MID,315,54,Color("ffe28a"))
        _center("СЧЁТ %d : %d" % [score_blue,score_red],MID,380,34)
        _center("НАЖМИ ДЛЯ ВОЗВРАТА В МЕНЮ",MID,458,27)
    elif goal_pause > 0:
        _center(message,MID,270,56,Color("ffe28a"))
    else:
        _center("ВЕДИ ФИГУРКУ ПАЛЬЦЕМ К МЯЧУ • ВРАТАРЬ ТОЖЕ УПРАВЛЯЕТСЯ",MID,682,20,Color("d3e2f3"))
