extends Node2D

const W := 960.0
const H := 600.0
const FX := 92.0
const FY := 122.0
const CW := 97.0
const CH := 85.0
const COLS := 8
const ROWS := 4
const CREAM := Color("f4eddb")
const BLUE := Color("48b9f3")
const RED := Color("ff795e")
const GOLD := Color("f9ce65")

var portraits: Array = []
var players: Array = []
var mode := 0 # 0 computer, 1 two local players
var phase := "menu" # menu, play, duel, aim, shot, finish
var turn := 0
var ball_owner := 1
var selected := 1
var score := [0, 0]
var turns_done := 0
var half := 1
var message := ""
var ai_wait := 0.0
var duel_a := -1
var duel_b := -1
var duel_meter := 0.0
var duel_dir := 1.0
var duel_target := 0.52
var duel_values := [-1.0, -1.0]
var duel_step := 0
var shot_timer := 0.0
var shot_from := Vector2.ZERO
var shot_target := Vector2.ZERO
var keeper_y := 0.0
var keeper_team := 1
var shooter := -1
var aim_y := 0.0
var last_goal := ""
var pointer_down := false
var canvas_scale := 1.0
var canvas_offset := Vector2.ZERO
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	for team in range(2):
		var arr: Array = []
		for frame in range(2):
			arr.append(load("res://assets/player_%d_%d.png" % [team, frame]))
		portraits.append(arr)
	set_process(true)

func _start(which: int) -> void:
	mode = which
	phase = "play"
	turn = 0
	score = [0, 0]
	turns_done = 0
	half = 1
	_reset_positions(0)
	message = "СИНИЕ начинают. Нажми на клетку или игрока."
	ai_wait = 0.8
	queue_redraw()

func _reset_positions(kickoff: int) -> void:
	players.clear()
	var initial := [Vector2i(1, 1), Vector2i(2, 2), Vector2i(2, 0), Vector2i(6, 2), Vector2i(5, 1), Vector2i(5, 3)]
	for i in range(6):
		players.append({"team": int(i / 3), "cell": initial[i], "stun": 0})
	ball_owner = 1 if kickoff == 0 else 4
	selected = ball_owner
	turn = kickoff

func _pos(cell: Vector2i) -> Vector2:
	return Vector2(FX + (float(cell.x) + 0.5) * CW, FY + (float(cell.y) + 0.5) * CH)

func _cell(at: Vector2) -> Vector2i:
	return Vector2i(int(floor((at.x - FX) / CW)), int(floor((at.y - FY) / CH)))

func _valid(c: Vector2i) -> bool:
	return c.x >= 0 and c.x < COLS and c.y >= 0 and c.y < ROWS

func _occupant(c: Vector2i) -> int:
	for i in range(players.size()):
		if players[i]["cell"] == c:
			return i
	return -1

func _team(idx: int) -> int:
	return int(players[idx]["team"])

func _can_control() -> bool:
	return mode == 1 or turn == 0

func _end_turn() -> void:
	turns_done += 1
	if turns_done == 24:
		half = 2
		message = "ВТОРОЙ ТАЙМ! Команды поменялись инициативой."
	if turns_done >= 48:
		phase = "finish"
		return
	turn = 1 - turn
	selected = _first_available(turn)
	ai_wait = 0.8

func _first_available(t: int) -> int:
	for i in range(players.size()):
		if _team(i) == t and int(players[i]["stun"]) == 0:
			return i
	return t * 3

func _try_cell(c: Vector2i) -> void:
	if not _valid(c) or not _can_control() or phase != "play":
		return
	var hit := _occupant(c)
	if hit >= 0 and _team(hit) == turn:
		if selected == ball_owner and hit != selected and ball_owner >= 0:
			_pass_to(hit)
		else:
			selected = hit
			message = "Выбран игрок №%d. Касайся соседней зоны." % [hit % 3 + 1]
		queue_redraw()
		return
	if selected < 0 or _team(selected) != turn:
		selected = _first_available(turn)
	if int(players[selected]["stun"]) > 0:
		players[selected]["stun"] = 0
		message = "Этот футболист оглушён после отбора: пропуск хода!"
		_end_turn()
		return
	var origin: Vector2i = players[selected]["cell"]
	var dist := abs(c.x - origin.x) + abs(c.y - origin.y)
	if dist < 1 or dist > 2:
		message = "За ход можно пройти максимум 2 зоны."
		return
	if hit >= 0:
		if _team(hit) != turn and (selected == ball_owner or hit == ball_owner):
			_begin_duel(selected, hit)
		else:
			message = "Зона занята соперником. Нужен игрок с мячом или отбор."
		return
	players[selected]["cell"] = c
	message = "Передвижение завершено. Ход другой команды."
	_end_turn()

func _pass_to(receiver: int) -> void:
	if ball_owner != selected or _team(receiver) != turn:
		return
	var a := _pos(players[ball_owner]["cell"])
	var b := _pos(players[receiver]["cell"])
	var interceptor := -1
	for i in range(players.size()):
		if _team(i) != turn:
			var p := _pos(players[i]["cell"])
			if _distance_to_segment(p, a, b) < 27.0:
				interceptor = i
	if interceptor >= 0 and rng.randf() < 0.65:
		ball_owner = interceptor
		message = "ПЕРЕХВАТ! Соперник прочитал передачу."
	else:
		ball_owner = receiver
		message = "Точный пас!"
	selected = ball_owner
	_end_turn()

func _distance_to_segment(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	if ab.length_squared() < 0.01:
		return p.distance_to(a)
	var t: float = clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + t * ab)

func _begin_duel(a: int, b: int) -> void:
	duel_a = a
	duel_b = b
	duel_step = 0
	duel_values = [-1.0, -1.0]
	duel_meter = 0.0
	duel_dir = 1.0
	duel_target = rng.randf_range(0.28, 0.72)
	phase = "duel"
	message = "ДУЭЛЬ! Останови бегунок ближе к золотой зоне."

func _duel_press() -> void:
	if phase != "duel":
		return
	duel_values[duel_step] = abs(duel_meter - duel_target)
	if mode == 0:
		if duel_step == 0 and turn == 0:
			duel_values[1] = rng.randf_range(0.06, 0.29)
			_finish_duel()
		else:
			duel_values[0] = rng.randf_range(0.06, 0.29)
			_finish_duel()
	else:
		if duel_step == 0:
			duel_step = 1
			duel_meter = 0.0
			duel_dir = 1.0
			duel_target = rng.randf_range(0.28, 0.72)
			message = "Передай телефон сопернику. Теперь его попытка!"
		else:
			_finish_duel()

func _finish_duel() -> void:
	var winner := duel_a if duel_values[0] <= duel_values[1] else duel_b
	var loser := duel_b if winner == duel_a else duel_a
	var had_ball := ball_owner
	ball_owner = winner
	selected = winner
	if had_ball == loser:
		players[loser]["stun"] = 1
		message = "ОТБОР! №%d теряет мяч и пропускает свой следующий ход." % [loser % 3 + 1]
	else:
		message = "Мяч у №%d. Дуэль выиграна!" % [winner % 3 + 1]
	phase = "play"
	_end_turn()

func _begin_aim() -> void:
	if phase != "play" or ball_owner < 0 or _team(ball_owner) != turn or not _can_control():
		message = "Бить может только команда с мячом."
		return
	var c: Vector2i = players[ball_owner]["cell"]
	if (turn == 0 and c.x < 4) or (turn == 1 and c.x > 3):
		message = "Для удара перейди на половину соперника!"
		return
	shooter = ball_owner
	keeper_team = 1 - turn
	aim_y = _pos(c).y
	phase = "aim"
	message = "Выбери точку в воротах соперника."

func _shoot(y: float) -> void:
	if phase != "aim":
		return
	shot_from = _pos(players[shooter]["cell"])
	shot_target = Vector2(FX + (COLS * CW) + 14.0 if turn == 0 else FX - 14.0, clampf(y, FY + 75.0, FY + ROWS * CH - 75.0))
	keeper_y = FY + ROWS * CH * 0.5
	shot_timer = 0.0
	phase = "shot"
	message = "УДАР! Двигай вратаря пальцем по вертикали!"

func _shot_resolve() -> void:
	var delta_y := abs(keeper_y - shot_target.y)
	if delta_y < 39.0:
		ball_owner = _first_available(keeper_team)
		message = "СЕЙВ! Вратарь отбил мяч. Владение у защиты."
	else:
		score[turn] += 1
		message = "ГОООЛ! %d : %d" % [score[0], score[1]]
		_reset_positions(keeper_team)
	phase = "play"
	_end_turn()
	if delta_y >= 39.0 and phase == "play":
		turn = keeper_team
		selected = ball_owner

func _process(delta: float) -> void:
	if phase == "duel":
		duel_meter += duel_dir * delta * 1.3
		if duel_meter >= 1.0:
			duel_meter = 1.0
			duel_dir = -1.0
		if duel_meter <= 0.0:
			duel_meter = 0.0
			duel_dir = 1.0
	elif phase == "shot":
		shot_timer += delta
		if mode == 0 and keeper_team == 1:
			var anticipation: float = clampf(shot_timer / 1.35, 0.0, 1.0)
			var desired := lerpf(FY + ROWS * CH * 0.5, shot_target.y + rng.randf_range(-0.8, 0.8), anticipation)
			keeper_y = move_toward(keeper_y, desired, delta * 65.0)
		if shot_timer >= 1.7:
			_shot_resolve()
	elif phase == "play" and mode == 0 and turn == 1:
		ai_wait -= delta
		if ai_wait <= 0.0:
			_ai_move()
	queue_redraw()

func _ai_move() -> void:
	if phase != "play" or turn != 1:
		return
	if ball_owner >= 0 and _team(ball_owner) == 1:
		selected = ball_owner
		var c: Vector2i = players[selected]["cell"]
		if c.x <= 3:
			_begin_aim()
			_shoot(_pos(c).y + rng.randf_range(-65.0, 65.0))
			return
		var next := Vector2i(maxi(c.x - 2, 0), c.y)
		var enemy := _occupant(next)
		if enemy >= 0 and _team(enemy) != 1:
			_begin_duel(selected, enemy)
			duel_values = [rng.randf_range(0.07, 0.24), rng.randf_range(0.07, 0.24)]
			_finish_duel()
		else:
			if enemy >= 0:
				next.y = clampi(c.y + (1 if c.y < 2 else -1), 0, 3)
			if _occupant(next) == -1:
				players[selected]["cell"] = next
			message = "Красные развивают атаку."
			_end_turn()
	else:
		var victim: Vector2i = players[ball_owner]["cell"]
		var defender := 3
		var best := 999
		for i in range(3, 6):
			var c: Vector2i = players[i]["cell"]
			var d := abs(c.x - victim.x) + abs(c.y - victim.y)
			if d < best:
				best = d
				defender = i
		selected = defender
		if best <= 2:
			_begin_duel(defender, ball_owner)
			duel_values = [rng.randf_range(0.07, 0.24), rng.randf_range(0.07, 0.24)]
			_finish_duel()
		else:
			var c: Vector2i = players[defender]["cell"]
			var target := c
			if victim.x < c.x:
				target.x = maxi(c.x - mini(2, c.x - victim.x), 0)
			elif victim.x > c.x:
				target.x = mini(c.x + mini(2, victim.x - c.x), 7)
			else:
				target.y = clampi(c.y + (1 if victim.y > c.y else -1), 0, 3)
			if _occupant(target) == -1:
				players[defender]["cell"] = target
			message = "Красные идут в прессинг."
			_end_turn()

func _input(event: InputEvent) -> void:
	var raw := Vector2.ZERO
	var pressed := false
	var dragging := false
	if event is InputEventScreenTouch:
		raw = event.position
		pressed = event.pressed
		dragging = event.pressed
	elif event is InputEventScreenDrag:
		raw = event.position
		dragging = true
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		raw = event.position
		pressed = event.pressed
		dragging = event.pressed
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		raw = event.position
		dragging = true
	else:
		return
	var p := (raw - canvas_offset) / canvas_scale
	if phase == "shot" and (pressed or dragging):
		if mode == 1 or keeper_team == 0:
			keeper_y = clampf(p.y, FY + 72.0, FY + ROWS * CH - 72.0)
		return
	if not pressed:
		return
	if phase == "menu":
		if Rect2(245, 318, 470, 67).has_point(p):
			_start(0)
		elif Rect2(245, 407, 470, 67).has_point(p):
			_start(1)
		return
	if phase == "finish":
		_start(mode)
		return
	if phase == "duel":
		_duel_press()
		return
	if phase == "aim":
		if p.y >= FY and p.y <= FY + ROWS * CH:
			_shoot(p.y)
		return
	if phase != "play" or not _can_control():
		return
	if Rect2(690, 513, 174, 60).has_point(p):
		_begin_aim()
	elif Rect2(476, 513, 190, 60).has_point(p):
		if ball_owner >= 0 and _team(ball_owner) != turn:
			selected = _first_available(turn)
			message = "Выбери соперника в пределах 2 зон для отбора."
		else:
			message = "Для паса нажми на своего партнёра."
	elif Rect2(92, 122, 776, 340).has_point(p):
		_try_cell(_cell(p))

func _draw() -> void:
	var vp := get_viewport_rect().size
	canvas_scale = minf(vp.x / W, vp.y / H)
	canvas_offset = (vp - Vector2(W, H) * canvas_scale) * 0.5
	draw_set_transform(canvas_offset, 0.0, Vector2.ONE * canvas_scale)
	draw_rect(Rect2(0, 0, W, H), Color("101c2c"))
	if phase == "menu":
		_menu()
	elif phase == "finish":
		_field()
		_panel(Vector2(175, 183), Vector2(610, 260), Color("14263b"))
		_label("МАТЧ ОКОНЧЕН", Vector2(310, 256), 38, GOLD)
		_label("СЧЁТ  %d : %d" % [score[0], score[1]], Vector2(365, 315), 33, CREAM)
		_label("Коснись экрана для нового матча", Vector2(275, 377), 22, CREAM)
	else:
		_field()
		_players()
		_hud()
		if phase == "duel":
			_duel_draw()
		elif phase == "aim":
			_aim_draw()
		elif phase == "shot":
			_shot_draw()
	draw_set_transform(Vector2.ZERO)

func _label(s: String, at: Vector2, size: int = 22, color: Color = CREAM) -> void:
	draw_string(ThemeDB.fallback_font, at, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _panel(at: Vector2, size: Vector2, color: Color) -> void:
	draw_rect(Rect2(at, size), color, true)
	draw_rect(Rect2(at, size), Color("d2caa6"), false, 2.0)

func _menu() -> void:
	draw_rect(Rect2(0, 0, W, 600), Color("142b38"))
	for i in range(17):
		draw_line(Vector2(i * 70, 0), Vector2(i * 70 - 150, 600), Color(0.3, 0.7, 0.65, 0.09), 3.0)
	_label("TOY FOOTBALL", Vector2(246, 143), 59, GOLD)
	_label("TACTICAL ARENA  •  4.0", Vector2(335, 193), 25, CREAM)
	_label("Пошаговая стратегия + дуэли + аэрохоккейный вратарь", Vector2(171, 258), 23, CREAM)
	_panel(Vector2(245, 318), Vector2(470, 67), Color("205f83"))
	_label("ИГРАТЬ ПРОТИВ БОТА", Vector2(319, 362), 28, CREAM)
	_panel(Vector2(245, 407), Vector2(470, 67), Color("853f3d"))
	_label("ДВА ИГРОКА НА ТЕЛЕФОНЕ", Vector2(270, 450), 27, CREAM)
	_label("3 на 3 + вратари  •  2 тайма по 24 действия", Vector2(230, 537), 20, Color("b9cbd2"))

func _field() -> void:
	draw_rect(Rect2(0, 0, W, H), Color("132738"))
	# The old asphalt texture is used as a subtle overlay on the playing field.
	var texture: Texture2D = load("res://assets/court.jpg")
	if texture != null:
		draw_texture_rect(texture, Rect2(FX, FY, CW * COLS, CH * ROWS), false, Color(1, 1, 1, 0.28))
	for x in range(COLS):
		for y in range(ROWS):
			var shade := Color("26634d") if (x + y) % 2 == 0 else Color("2b7154")
			shade.a = 0.76
			draw_rect(Rect2(FX + x * CW, FY + y * CH, CW, CH), shade)
	for x in range(COLS + 1):
		draw_line(Vector2(FX + x * CW, FY), Vector2(FX + x * CW, FY + ROWS * CH), Color(0.85, 0.94, 0.82, 0.38), 1.6)
	for y in range(ROWS + 1):
		draw_line(Vector2(FX, FY + y * CH), Vector2(FX + COLS * CW, FY + y * CH), Color(0.85, 0.94, 0.82, 0.38), 1.6)
	draw_line(Vector2(FX + 4 * CW, FY), Vector2(FX + 4 * CW, FY + ROWS * CH), CREAM, 3.0)
	draw_arc(Vector2(FX + 4 * CW, FY + 2 * CH), 49.0, 0, TAU, 32, CREAM, 2.0)
	draw_rect(Rect2(FX - 21, FY + 70, 21, 200), BLUE)
	draw_rect(Rect2(FX + COLS * CW, FY + 70, 21, 200), RED)
	_label("ЛЕВЫЕ ВОРОТА", Vector2(94, 111), 15, BLUE)
	_label("ПРАВЫЕ ВОРОТА", Vector2(697, 111), 15, RED)

func _players() -> void:
	for i in range(players.size()):
		var p := _pos(players[i]["cell"])
		var team := _team(i)
		var color := BLUE if team == 0 else RED
		if i == selected and phase == "play":
			draw_arc(p, 36, 0, TAU, 32, GOLD, 4.0)
		if int(players[i]["stun"]) > 0:
			draw_circle(p, 34, Color(0.3, 0.3, 0.3, 0.52))
		var frame := int(Time.get_ticks_msec() / 320) % 2
		var tex: Texture2D = portraits[team][frame]
		if tex != null:
			draw_texture_rect(tex, Rect2(p - Vector2(26, 40), Vector2(52, 72)), false)
		else:
			draw_circle(p, 21, color)
		_label(str(i % 3 + 1), p + Vector2(-6, 23), 19, Color("ffffff"))
		if i == ball_owner:
			draw_circle(p + Vector2(25, 21), 12, Color("ffffff"))
			draw_arc(p + Vector2(25, 21), 7, 0, TAU, 6, Color("15283b"), 2.0)
		if int(players[i]["stun"]) > 0:
			_label("Zz", p + Vector2(-10, -38), 19, GOLD)

func _hud() -> void:
	_label("СИНИЕ  %d" % score[0], Vector2(95, 47), 29, BLUE)
	_label("%d  КРАСНЫЕ" % score[1], Vector2(698, 47), 29, RED)
	_label("ТАЙМ %d / 2    ХОД %d / 48" % [half, mini(turns_done + 1, 48)], Vector2(349, 43), 21, GOLD)
	var name := "СИНИХ" if turn == 0 else "КРАСНЫХ"
	_label("ХОД " + name + (" (БОТ)" if mode == 0 and turn == 1 else ""), Vector2(96, 84), 24, CREAM)
	_label(message, Vector2(93, 496), 19, CREAM)
	_panel(Vector2(476, 513), Vector2(190, 60), Color("325b70"))
	_label("ПАС / ОТБОР", Vector2(493, 550), 22, CREAM)
	_panel(Vector2(690, 513), Vector2(174, 60), Color("b35b37"))
	_label("УДАР", Vector2(741, 552), 28, CREAM)
	_label("Ход: коснись игрока → зоны. Пас: коснись партнёра.", Vector2(93, 557), 17, Color("b2c5c7"))

func _duel_draw() -> void:
	_panel(Vector2(165, 176), Vector2(630, 255), Color("17283c"))
	_label("МИНИ-ИГРА: БОРЬБА ЗА МЯЧ", Vector2(220, 226), 29, GOLD)
	_label("Останови бегунок как можно ближе к метке", Vector2(224, 268), 21, CREAM)
	var left := 238.0
	var top := 311.0
	draw_rect(Rect2(left, top, 485, 29), Color("334b5b"))
	draw_rect(Rect2(left + duel_target * 485.0 - 15.0, top, 30, 29), GOLD)
	draw_rect(Rect2(left + duel_meter * 485.0 - 4.0, top - 9.0, 8, 47), Color("ffffff"))
	_label("ИГРОК %d: НАЖМИ НА ЭКРАН" % (duel_step + 1), Vector2(300, 389), 23, CREAM)

func _aim_draw() -> void:
	_panel(Vector2(186, 182), Vector2(588, 158), Color("17283c"))
	_label("ВЫБЕРИ ТОЧКУ УДАРА", Vector2(295, 235), 32, GOLD)
	_label("Коснись нужной высоты поля — туда полетит мяч", Vector2(215, 286), 19, CREAM)

func _shot_draw() -> void:
	var t: float = clampf(shot_timer / 1.7, 0.0, 1.0)
	var current := shot_from.lerp(shot_target, t)
	draw_line(shot_from, shot_target, Color(1, 0.9, 0.4, 0.36), 3.0)
	draw_circle(current, 15, Color("fff9e8"))
	var gx := FX + COLS * CW + 5.0 if keeper_team == 1 else FX - 5.0
	draw_line(Vector2(gx, keeper_y - 37), Vector2(gx, keeper_y + 37), GOLD, 17.0)
	_panel(Vector2(228, 30), Vector2(504, 48), Color("17283c"))
	_label("ВРАТАРЬ: ВЕДИ ПАЛЬЦЕМ ВВЕРХ / ВНИЗ", Vector2(243, 61), 21, GOLD)
