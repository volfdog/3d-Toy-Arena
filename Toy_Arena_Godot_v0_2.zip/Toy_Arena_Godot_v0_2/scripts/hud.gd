extends CanvasLayer
## В версии 0.2 экранные кнопки обрабатываются вручную по координатам касаний.
## Это позволяет использовать несколько пальцев и не зависеть от реакции Button в Safari.

signal attack_requested
signal defense_changed(held: bool)
signal ultimate_requested
signal restart_requested
signal start_requested

var root: Control
var hero_label: Label
var foe_label: Label
var hero_hp: ProgressBar
var foe_hp: ProgressBar
var hero_hp_value: Label
var foe_hp_value: Label
var energy_bar: ProgressBar
var timer_label: Label
var attack_button: Button
var defense_button: Button
var ultimate_button: Button
var instruction: Label
var result_overlay: ColorRect
var result_title: Label
var restart_button: Button
var start_overlay: ColorRect
var start_title: Label
var start_hint: Label
var start_button: Button
var rotate_overlay: ColorRect
var rotate_label: Label
var _defense_pointer: int = -999

func _ready() -> void:
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)

    hero_label = _label("РЫЦАРЬ-ИГРУШКА", 25, Color("d6f7ff"))
    foe_label = _label("ВАМПИР-ИГРУШКА", 25, Color("ffe5eb"))
    hero_hp = _bar(Color("44d98e"))
    foe_hp = _bar(Color("ff5379"))
    hero_hp_value = _label("100/100 HP", 19)
    foe_hp_value = _label("100/100 HP", 19)
    timer_label = _label("01:15", 40, Color("fff4af"))
    energy_bar = _bar(Color("49d4fd"))

    attack_button = _button("АТАКА", Color("eb3950"), Color("ffd77b"), 27)
    defense_button = _button("ЗАЩИТА", Color("227bc8"), Color("82e8ff"), 26)
    ultimate_button = _button("УЛЬТА 0%", Color("943ac8"), Color("f5c0ff"), 22)
    instruction = _label("ТАП ПО АРЕНЕ — БЕГ • ПЕРВАЯ МИНУТА БЕЗ НОКАУТА", 20, Color("ffffff"))

    result_overlay = ColorRect.new()
    result_overlay.color = Color(0.04, 0.055, 0.11, 0.86)
    result_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(result_overlay)
    result_title = _label("ПОБЕДА!", 54, Color("ffe695"), result_overlay)
    restart_button = _button("ЕЩЁ БОЙ", Color("2177bb"), Color("9df0ff"), 30, result_overlay)
    result_overlay.visible = false

    start_overlay = ColorRect.new()
    start_overlay.color = Color(0.04, 0.08, 0.16, 0.87)
    start_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(start_overlay)
    start_title = _label("TOY ARENA 3D", 63, Color("ffe79e"), start_overlay)
    start_hint = _label("75 СЕКУНД БОЯ • 60 СЕКУНД БЕЗ НОКАУТА", 27, Color("e5f8ff"), start_overlay)
    start_button = _button("НАЧАТЬ БОЙ", Color("23a05f"), Color("d6ffa7"), 32, start_overlay)

    rotate_overlay = ColorRect.new()
    rotate_overlay.color = Color("0d2345")
    rotate_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(rotate_overlay)
    rotate_label = _label("ПОВЕРНИ ТЕЛЕФОН ГОРИЗОНТАЛЬНО", 25, Color("fff3bc"), rotate_overlay)
    get_viewport().size_changed.connect(_layout)
    _layout()

func hide_start() -> void:
    start_overlay.visible = false

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        _handle_pointer(event.position, event.pressed, event.index)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        _handle_pointer(event.position, event.pressed, -1)

func _handle_pointer(point: Vector2, pressed: bool, pointer: int) -> void:
    if not pressed and pointer == _defense_pointer:
        _defense_pointer = -999
        defense_changed.emit(false)
        get_viewport().set_input_as_handled()
        return
    if rotate_overlay.visible:
        get_viewport().set_input_as_handled()
        return
    if result_overlay.visible:
        if pressed and restart_button.get_global_rect().has_point(point):
            restart_requested.emit()
        get_viewport().set_input_as_handled()
        return
    if start_overlay.visible:
        if pressed and start_button.get_global_rect().has_point(point):
            start_requested.emit()
        get_viewport().set_input_as_handled()
        return
    if not pressed:
        return
    if attack_button.get_global_rect().has_point(point):
        attack_requested.emit()
        get_viewport().set_input_as_handled()
    elif defense_button.get_global_rect().has_point(point):
        _defense_pointer = pointer
        defense_changed.emit(true)
        get_viewport().set_input_as_handled()
    elif ultimate_button.get_global_rect().has_point(point):
        if not ultimate_button.disabled:
            ultimate_requested.emit()
        get_viewport().set_input_as_handled()

func _label(text_: String, font_size: int, color: Color = Color.WHITE, parent: Control = null) -> Label:
    var label := Label.new()
    label.text = text_
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    (parent if parent != null else root).add_child(label)
    return label

func _bar(fill: Color) -> ProgressBar:
    var bar := ProgressBar.new()
    bar.min_value = 0.0
    bar.max_value = 100.0
    bar.value = 100.0
    bar.show_percentage = false
    bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var bg := StyleBoxFlat.new()
    bg.bg_color = Color("162741")
    bg.set_corner_radius_all(12)
    bg.border_color = Color("ffffff")
    bg.set_border_width_all(2)
    bar.add_theme_stylebox_override("background", bg)
    var fg := StyleBoxFlat.new()
    fg.bg_color = fill
    fg.set_corner_radius_all(12)
    bar.add_theme_stylebox_override("fill", fg)
    root.add_child(bar)
    return bar

func _button(text_: String, fill: Color, border: Color, font_size: int, parent: Control = null) -> Button:
    var b := Button.new()
    b.text = text_
    b.focus_mode = Control.FOCUS_NONE
    b.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color.WHITE)
    for mode in ["normal", "hover", "pressed", "disabled", "focus"]:
        var style := StyleBoxFlat.new()
        style.bg_color = fill.lightened(0.15) if mode == "pressed" else fill.darkened(0.45) if mode == "disabled" else fill
        style.border_color = border
        style.set_border_width_all(5)
        style.set_corner_radius_all(75)
        style.shadow_color = Color(0, 0, 0, 0.4)
        style.shadow_size = 5
        b.add_theme_stylebox_override(mode, style)
    (parent if parent != null else root).add_child(b)
    return b

func _place(node: Control, x: float, y: float, w: float, h: float) -> void:
    node.position = Vector2(x, y)
    node.size = Vector2(w, h)

func _layout() -> void:
    var viewport_size := get_viewport().get_visible_rect().size
    var w: float = viewport_size.x
    var h: float = viewport_size.y
    var s: float = minf(w / 1280.0, h / 720.0)
    _place(hero_label, 22*s, 14*s, 340*s, 38*s)
    _place(hero_hp, 28*s, 62*s, 300*s, 30*s)
    _place(hero_hp_value, 28*s, 95*s, 300*s, 26*s)
    _place(foe_label, w - 370*s, 14*s, 345*s, 38*s)
    _place(foe_hp, w - 330*s, 62*s, 300*s, 30*s)
    _place(foe_hp_value, w - 330*s, 95*s, 300*s, 26*s)
    _place(timer_label, w*0.5 - 100*s, 17*s, 200*s, 67*s)
    _place(energy_bar, w*0.5 - 92*s, 98*s, 184*s, 17*s)
    _place(attack_button, 18*s, h - 209*s, 176*s, 176*s)
    _place(defense_button, w - 194*s, h - 209*s, 176*s, 176*s)
    _place(ultimate_button, w - 182*s, h - 372*s, 149*s, 149*s)
    _place(instruction, w*0.5 - 335*s, h - 45*s, 670*s, 36*s)
    _place(result_overlay, 0, 0, w, h)
    _place(result_title, w*0.5 - 310*s, h*0.5 - 137*s, 620*s, 92*s)
    _place(restart_button, w*0.5 - 170*s, h*0.5 + 10*s, 340*s, 110*s)
    _place(start_overlay, 0, 0, w, h)
    _place(start_title, w*0.5 - 385*s, h*0.5 - 190*s, 770*s, 110*s)
    _place(start_hint, w*0.5 - 440*s, h*0.5 - 65*s, 880*s, 65*s)
    _place(start_button, w*0.5 - 184*s, h*0.5 + 55*s, 368*s, 112*s)
    _place(rotate_overlay, 0, 0, w, h)
    _place(rotate_label, 20*s, h*0.5 - 66*s, w - 40*s, 132*s)
    rotate_overlay.visible = h > w

func update_stats(hero_health: float, enemy_health: float, hero_stamina: float, hero_ult: float, seconds_left: float) -> void:
    hero_hp.value = hero_health
    foe_hp.value = enemy_health
    hero_hp_value.text = "%d/100 HP  •  ЩИТ %d%%" % [ceili(hero_health), ceili(hero_stamina)]
    foe_hp_value.text = "%d/100 HP" % ceili(enemy_health)
    energy_bar.value = hero_ult
    ultimate_button.disabled = hero_ult < 99.99
    ultimate_button.text = "УЛЬТА!" if hero_ult >= 99.99 else "УЛЬТА %d%%" % floori(hero_ult)
    var t := maxi(0, ceili(seconds_left))
    timer_label.text = "%02d:%02d" % [floori(float(t) / 60.0), t % 60]

func show_result(title_: String) -> void:
    result_title.text = title_
    result_overlay.visible = true
    _defense_pointer = -999
