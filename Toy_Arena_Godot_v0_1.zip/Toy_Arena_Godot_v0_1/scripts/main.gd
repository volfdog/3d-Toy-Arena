extends Node3D
## Toy Arena 0.1: самостоятельный 3D-прототип с ботом и мультитач-UI.
## Ни один файл Monster Ball не используется.

const FighterScript = preload("res://scripts/fighter.gd")
const HudScript = preload("res://scripts/hud.gd")
const ROUND_SECONDS: float = 90.0
const HIT_RANGE: float = 2.50
const ATTACK_DAMAGE: float = 12.0
const BLOCKED_DAMAGE: float = 2.5
const ATTACK_COOLDOWN: float = 0.43

var camera: Camera3D
var hero
var enemy
var hud
var time_left: float = ROUND_SECONDS
var playing: bool = true
var bot_rethink: float = 0.0
var bot_block_left: float = 0.0
var bot_block_next: float = 1.3
var _touch_blocking: bool = false

func _ready() -> void:
	randomize()
	_create_stage()
	camera = Camera3D.new()
	camera.name = "TopDownThreeQuarterCamera"
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 25.0
	camera.position = Vector3(0.0, 19.0, 22.5)
	add_child(camera)
	camera.look_at(Vector3(0, 0.15, 0), Vector3.UP)
	camera.current = true

	hero = FighterScript.new()
	hero.name = "KnightToy"
	hero.is_player = true
	hero.is_vampire = false
	hero.move_speed = 10.0
	hero.position = Vector3(-3.8, 0.0, 2.0)
	add_child(hero)

	enemy = FighterScript.new()
	enemy.name = "VampireToyBot"
	enemy.is_player = false
	enemy.is_vampire = true
	enemy.move_speed = 8.9
	enemy.position = Vector3(3.8, 0.0, -2.1)
	add_child(enemy)
	hero.face_position(enemy.global_position)
	enemy.face_position(hero.global_position)

	hud = HudScript.new()
	add_child(hud)
	hud.attack_requested.connect(_on_player_attack)
	hud.defense_changed.connect(_on_player_defense)
	hud.ultimate_requested.connect(_on_player_ultimate)
	hud.restart_requested.connect(func(): get_tree().reload_current_scene())
	hud.update_stats(hero.health, enemy.health, hero.stamina, hero.ultimate_charge, time_left)

func _process(delta: float) -> void:
	if not playing:
		return
	time_left -= delta
	_update_bot(delta)
	hud.update_stats(hero.health, enemy.health, hero.stamina, hero.ultimate_charge, time_left)
	if time_left <= 0.0:
		if hero.health > enemy.health:
			_finish("ПОБЕДА ПО HP!")
		elif enemy.health > hero.health:
			_finish("ПОРАЖЕНИЕ ПО HP")
		else:
			_finish("НИЧЬЯ!")

func _unhandled_input(event: InputEvent) -> void:
	if not playing:
		return
	# Указание цели только на игровом поле, не на боевых кнопках.
	if event is InputEventScreenTouch and event.pressed:
		_set_destination_from_screen(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_set_destination_from_screen(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE:
			_on_player_attack()
		elif event.keycode == KEY_E:
			_on_player_ultimate()

func _physics_process(_delta: float) -> void:
	# Тест блокирования на ПК (на телефоне удерживается экранная кнопка).
	if playing and Input.is_key_pressed(KEY_SHIFT):
		hero.block_requested = true
	elif playing and not Input.is_key_pressed(KEY_SHIFT) and not _touch_blocking:
		hero.block_requested = false

func _on_player_defense(held: bool) -> void:
	_touch_blocking = held
	if playing:
		hero.block_requested = held

func _on_player_attack() -> void:
	_try_attack(hero, enemy)

func _on_player_ultimate() -> void:
	_try_ultimate(hero, enemy)

func _set_destination_from_screen(screen_pos: Vector2) -> void:
	var ray_origin: Vector3 = camera.project_ray_origin(screen_pos)
	var ray_direction: Vector3 = camera.project_ray_normal(screen_pos)
	if absf(ray_direction.y) < 0.00001:
		return
	var t: float = -ray_origin.y / ray_direction.y
	if t < 0.0:
		return
	var target: Vector3 = ray_origin + ray_direction * t
	hero.set_destination(target)

func _try_attack(attacker, target) -> void:
	if not playing or not attacker.active or not target.active or attacker.attack_cooldown > 0.0:
		return
	attacker.attack_cooldown = ATTACK_COOLDOWN
	attacker.face_position(target.global_position)
	attacker.animate_attack()
	if attacker.global_position.distance_to(target.global_position) > HIT_RANGE:
		return
	var amount: float = BLOCKED_DAMAGE if target.blocking else ATTACK_DAMAGE
	target.damage(amount)
	attacker.ultimate_charge = minf(100.0, attacker.ultimate_charge + (12.0 if target.blocking else 23.0))
	target.ultimate_charge = minf(100.0, target.ultimate_charge + 11.0)
	_spawn_hit_spark(target.global_position + Vector3(0, 1.3, 0), Color("7cdffe") if attacker.is_player else Color("ff587a"))
	if target.health <= 0.0:
		_finish("ПОБЕДА!" if attacker.is_player else "ПОРАЖЕНИЕ")

func _try_ultimate(attacker, target) -> void:
	if not playing or not attacker.active or not target.active or attacker.ultimate_charge < 99.99:
		return
	attacker.ultimate_charge = 0.0
	attacker.attack_cooldown = 0.65
	# Быстрый игрушечный рывок: техническая заготовка для будущей анимации.
	var direction: Vector3 = (target.global_position - attacker.global_position).normalized()
	direction.y = 0.0
	if direction.length_squared() < 0.01:
		direction = Vector3.FORWARD
	var new_position: Vector3 = target.global_position - direction * 1.65
	var new_flat := Vector2(new_position.x, new_position.z)
	if new_flat.length() > attacker.arena_radius:
		new_flat = new_flat.normalized() * attacker.arena_radius
	attacker.global_position = Vector3(new_flat.x, 0.0, new_flat.y)
	attacker.stop()
	attacker.face_position(target.global_position)
	attacker.animate_attack()
	_spawn_hit_spark(attacker.global_position + Vector3(0, 1.1, 0), Color("69e2ff") if attacker.is_player else Color("ff628c"), 2.2)
	if attacker.global_position.distance_to(target.global_position) <= 3.10:
		target.damage(32.0 if attacker.is_player else 28.0)
		_spawn_hit_spark(target.global_position + Vector3(0, 1.3, 0), Color("fff6b1"), 1.6)
		if target.health <= 0.0:
			_finish("ПОБЕДА!" if attacker.is_player else "ПОРАЖЕНИЕ")

func _update_bot(delta: float) -> void:
	bot_rethink -= delta
	bot_block_next -= delta
	bot_block_left -= delta
	var distance: float = enemy.global_position.distance_to(hero.global_position)
	if bot_block_left <= 0.0:
		enemy.block_requested = false
	if bot_rethink <= 0.0:
		bot_rethink = 0.16
		if distance > 2.0:
			enemy.set_destination(hero.global_position)
		else:
			enemy.stop()
		if distance <= HIT_RANGE and enemy.attack_cooldown <= 0.0:
			_try_attack(enemy, hero)
		if enemy.ultimate_charge >= 99.99 and distance < 5.5:
			_try_ultimate(enemy, hero)
		if bot_block_next <= 0.0 and distance < 3.1 and enemy.stamina > 26.0:
			enemy.block_requested = true
			bot_block_left = randf_range(0.35, 0.85)
			bot_block_next = randf_range(1.5, 3.2)

func _finish(message: String) -> void:
	if not playing:
		return
	playing = false
	hero.active = false
	enemy.active = false
	hero.block_requested = false
	enemy.block_requested = false
	hud.update_stats(hero.health, enemy.health, hero.stamina, hero.ultimate_charge, time_left)
	hud.show_result(message)

func _material(color: Color, emissive: bool = false) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.64
	if emissive:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 1.8
	return mat

func _mesh_item(mesh_: Mesh, material_: Material, point: Vector3, label_: String = "") -> MeshInstance3D:
	var item := MeshInstance3D.new()
	item.mesh = mesh_
	item.material_override = material_
	item.position = point
	item.name = label_
	add_child(item)
	return item

func _create_stage() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("100e21")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("9fa5d4")
	env.ambient_light_energy = 0.95
	env_node.environment = env
	add_child(env_node)

	var sunlight := DirectionalLight3D.new()
	sunlight.light_color = Color("ffcfab")
	sunlight.light_energy = 1.45
	sunlight.rotation_degrees = Vector3(-50, -30, 0)
	add_child(sunlight)

	var base := CylinderMesh.new()
	base.top_radius = 10.15
	base.bottom_radius = 10.4
	base.height = 0.50
	_mesh_item(base, _material(Color("302a43")), Vector3(0, -0.24, 0), "CircularStonePlatform")

	# Небольшое число 3D-камней, чтобы прототип оставался лёгким для мобильного WebGL.
	for ix in range(-5, 6):
		for iz in range(-5, 6):
			var x := float(ix) * 1.79
			var z := float(iz) * 1.79
			if Vector2(x, z).length() >= 9.50:
				continue
			var block := BoxMesh.new()
			block.size = Vector3(1.73, 0.085, 1.73)
			var shade: float = float((abs(ix * 3 + iz * 5) % 5)) * 0.026
			_mesh_item(block, _material(Color(0.25 + shade, 0.24 + shade * 0.6, 0.33 + shade)), Vector3(x, 0.015, z), "StoneTile")

	# Светящееся кольцо показывает границу активной области.
	_add_ground_ring(8.92, 9.00, Color("7556bc"))
	_add_ground_ring(4.65, 4.70, Color("54417e"))

	var column_mat := _material(Color("4b405c"))
	var torch_mat := _material(Color("ff9a4f"), true)
	for i in range(12):
		var angle: float = TAU * float(i) / 12.0
		var x := cos(angle) * 10.55
		var z := sin(angle) * 10.55
		var col := CylinderMesh.new()
		col.top_radius = 0.54
		col.bottom_radius = 0.72
		col.height = 2.1
		_mesh_item(col, column_mat, Vector3(x, 1.0, z), "GothicPillar")
		var cap := CylinderMesh.new()
		cap.top_radius = 0.64
		cap.bottom_radius = 0.64
		cap.height = 0.22
		_mesh_item(cap, column_mat, Vector3(x, 2.13, z), "PillarCap")
		if i % 2 == 0:
			var glow := SphereMesh.new()
			glow.radius = 0.30
			glow.height = 0.55
			_mesh_item(glow, torch_mat, Vector3(x, 2.57, z), "TorchGlow")

	# Два источника света вместо десятков: экономим ресурсы телефона.
	for light_pos in [Vector3(-7, 6, -5), Vector3(7, 6, 5)]:
		var colored_light := OmniLight3D.new()
		colored_light.position = light_pos
		colored_light.light_color = Color("875eff")
		colored_light.light_energy = 0.70
		colored_light.omni_range = 15.0
		add_child(colored_light)

func _add_ground_ring(inner: float, outer: float, color: Color) -> void:
	var vertices := PackedVector3Array()
	for i in range(64):
		var a: float = TAU * float(i) / 64.0
		var b: float = TAU * float(i + 1) / 64.0
		for radius_and_angle in [Vector2(inner, a), Vector2(outer, b), Vector2(outer, a), Vector2(inner, a), Vector2(inner, b), Vector2(outer, b)]:
			vertices.append(Vector3(cos(radius_and_angle.y) * radius_and_angle.x, 0.066, sin(radius_and_angle.y) * radius_and_angle.x))
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var ring := ArrayMesh.new()
	ring.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_item(ring, _material(color, true), Vector3.ZERO, "ArcaneGroundRune")

func _spawn_hit_spark(point: Vector3, color: Color, radius_multiplier: float = 1.0) -> void:
	var spark := SphereMesh.new()
	spark.radius = 0.42
	spark.height = 0.84
	var node := _mesh_item(spark, _material(color, true), point, "ImpactFlash")
	node.scale = Vector3.ONE * 0.4 * radius_multiplier
	var tween := create_tween()
	tween.tween_property(node, "scale", Vector3.ONE * 1.32 * radius_multiplier, 0.095)
	tween.tween_property(node, "scale", Vector3.ZERO, 0.16)
	tween.tween_callback(node.queue_free)
