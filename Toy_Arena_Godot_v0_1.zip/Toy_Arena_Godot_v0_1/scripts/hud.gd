extends CanvasLayer
## Интерактивный интерфейс для горизонтального телефона.

signal attack_requested
signal defense_changed(held: bool)
signal ultimate_requested
signal restart_requested

var root: Control
var hero_label: Label
var foe_label: Label
var hero_hp: ProgressBar
var foe_hp: ProgressBar
var hero_hp_value: Label
var foe_hp_value: Label
var energy_bar: ProgressBar
var timer_label: Label
var attack_button: Button
var defense_button: Button
var ultimate_button: Button
var instruction: Label
var result_overlay: ColorRect
var result_title: Label
var restart_button: Button
var rotate_overlay: ColorRect
var rotate_label: Label

func _ready() -> void:
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	hero_label = _label("РЫЦАРЬ-ИГРУШКА", 23, Color("d5f5ff"))
	foe_label = _label("ВАМПИР-ИГРУШКА", 23, Color("ffe3ec"))
	hero_hp = _bar(Color("45dd8f"))
	foe_hp = _bar(Color("ff566e"))
	hero_hp_value = _label("100/100", 18)
	foe_hp_value = _label("100/100", 18)
	timer_label = _label("01:30", 32, Color("ffe0a1"))
	energy_bar = _bar(Color("52d4fc"))

	attack_button = _button("АТАКА", Color("a82934"), Color("ff8a65"), 20)
	defense_button = _button("ЗАЩИТА", Color("144e89"), Color("75caff"), 20)
	ultimate_button = _button("УЛЬТА 0%", Color("552c7f"), Color("b981ff"), 20)
	attack_button.button_down.connect(func(): attack_requested.emit())
	defense_button.button_down.connect(func(): defense_changed.emit(true))
	defense_button.button_up.connect(func(): defense_changed.emit(false))
	ultimate_button.button_down.connect(func(): ultimate_requested.emit())
	instruction = _label("ТАП ПО ПОЛЮ — ДВИЖЕНИЕ  •  БЬЁМ ВБЛИЗИ  •  ЩИТ ДЕРЖАТЬ", 17, Color("f4e2c4"))

	result_overlay = ColorRect.new()
	result_overlay.color = Color(0.03, 0.025, 0.09, 0.85)
	result_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(result_overlay)
	result_overlay.visible = false
	result_title = _label("ПОБЕДА!", 52, Color("ffdb89"), result_overlay)
	restart_button = _button("ЕЩЁ БОЙ", Color("245b92"), Color("8ddaff"), 24, result_overlay)
	restart_button.pressed.connect(func(): restart_requested.emit())

	rotate_overlay = ColorRect.new()
	rotate_overlay.color = Color("10142a")
	rotate_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(rotate_overlay)
	rotate_label = _label("ПОВЕРНИ ТЕЛЕФОН ГОРИЗОНТАЛЬНО", 24, Color("f9eac4"), rotate_overlay)
	get_viewport().size_changed.connect(_layout)
	_layout()

func _label(text_: String, font_size: int, color: Color = Color.WHITE, parent: Control = null) -> Label:
	var label := Label.new()
	label.text = text_
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	(parent if parent != null else root).add_child(label)
	return label

func _bar(fill: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = 100.0
	bar.value = 100.0
	bar.show_percentage = false
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color("171629")
	bg.set_corner_radius_all(9)
	bg.border_color = Color("9b8e9b")
	bg.set_border_width_all(2)
	bar.add_theme_stylebox_override("background", bg)
	var fg := StyleBoxFlat.new()
	fg.bg_color = fill
	fg.set_corner_radius_all(8)
	bar.add_theme_stylebox_override("fill", fg)
	root.add_child(bar)
	return bar

func _button(text_: String, fill: Color, border: Color, font_size: int, parent: Control = null) -> Button:
	var b := Button.new()
	b.text = text_
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", Color.WHITE)
	for mode in ["normal", "hover", "pressed", "disabled", "focus"]:
		var style := StyleBoxFlat.new()
		style.bg_color = fill.lightened(0.19) if mode == "pressed" else fill.darkened(0.47) if mode == "disabled" else fill
		style.border_color = border
		style.set_border_width_all(4)
		style.set_corner_radius_all(70)
		style.shadow_color = Color(0, 0, 0, 0.45)
		style.shadow_size = 7
		b.add_theme_stylebox_override(mode, style)
	(parent if parent != null else root).add_child(b)
	return b

func _place(node: Control, x: float, y: float, w: float, h: float) -> void:
	node.position = Vector2(x, y)
	node.size = Vector2(w, h)

func _layout() -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	var w := viewport_size.x
	var h := viewport_size.y
	var s: float = minf(w / 1280.0, h / 720.0)
	_place(hero_label, 42 * s, 19 * s, 320 * s, 34 * s)
	_place(hero_hp, 44 * s, 60 * s, 305 * s, 24 * s)
	_place(hero_hp_value, 44 * s, 86 * s, 305 * s, 23 * s)
	_place(foe_label, w - 375 * s, 19 * s, 330 * s, 34 * s)
	_place(foe_hp, w - 350 * s, 60 * s, 305 * s, 24 * s)
	_place(foe_hp_value, w - 350 * s, 86 * s, 305 * s, 23 * s)
	_place(timer_label, w * 0.5 - 96 * s, 27 * s, 192 * s, 62 * s)
	_place(energy_bar, w * 0.5 - 85 * s, 98 * s, 170 * s, 10 * s)
	_place(attack_button, 34 * s, h - 174 * s, 138 * s, 138 * s)
	_place(defense_button, w - 171 * s, h - 174 * s, 138 * s, 138 * s)
	_place(ultimate_button, w - 161 * s, h - 335 * s, 118 * s, 118 * s)
	_place(instruction, w * 0.5 - 260 * s, h - 51 * s, 520 * s, 37 * s)
	_place(result_overlay, 0, 0, w, h)
	_place(result_title, w * 0.5 - 270 * s, h * 0.5 - 112 * s, 540 * s, 82 * s)
	_place(restart_button, w * 0.5 - 125 * s, h * 0.5 + 30 * s, 250 * s, 70 * s)
	_place(rotate_overlay, 0, 0, w, h)
	_place(rotate_label, 24 * s, h * 0.5 - 64 * s, w - 48 * s, 128 * s)
	rotate_overlay.visible = h > w

func update_stats(hero_health: float, enemy_health: float, hero_stamina: float, hero_ult: float, seconds_left: float) -> void:
	hero_hp.value = hero_health
	foe_hp.value = enemy_health
	hero_hp_value.text = "%d/100 HP  •  ЩИТ %d%%" % [ceili(hero_health), ceili(hero_stamina)]
	foe_hp_value.text = "%d/100 HP" % ceili(enemy_health)
	energy_bar.value = hero_ult
	ultimate_button.disabled = hero_ult < 99.99
	ultimate_button.text = "УЛЬТА!" if hero_ult >= 99.99 else "УЛЬТА %d%%" % floori(hero_ult)
	var t := maxi(0, ceili(seconds_left))
	timer_label.text = "%02d:%02d" % [floori(float(t) / 60.0), t % 60]

func show_result(title_: String) -> void:
	result_title.text = title_
	result_overlay.visible = true
