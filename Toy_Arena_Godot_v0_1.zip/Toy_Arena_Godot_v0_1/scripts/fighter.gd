extends CharacterBody3D
## Временные 3D-фигурки из примитивов. Позже их заменят полноценные модели игрушек.

var is_player: bool = false
var is_vampire: bool = false
var health: float = 100.0
var stamina: float = 100.0
var ultimate_charge: float = 0.0
var blocking: bool = false
var block_requested: bool = false
var active: bool = true
var attack_cooldown: float = 0.0
var move_speed: float = 9.6
var arena_radius: float = 9.15

var destination: Vector3 = Vector3.ZERO
var has_destination: bool = false
var model: Node3D
var sword_pivot: Node3D
var block_glow: MeshInstance3D
var walk_clock: float = 0.0
var strike_tween: Tween
var bump_tween: Tween

func _ready() -> void:
	collision_layer = 2
	collision_mask = 2
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.40
	capsule.height = 1.65
	shape.shape = capsule
	shape.position.y = 0.83
	add_child(shape)
	_build_toy_model()

func set_destination(point: Vector3) -> void:
	if not active:
		return
	var p := Vector2(point.x, point.z)
	if p.length() > arena_radius:
		p = p.normalized() * arena_radius
	destination = Vector3(p.x, 0.0, p.y)
	has_destination = true

func stop() -> void:
	has_destination = false

func face_position(point: Vector3) -> void:
	var direction := point - global_position
	direction.y = 0.0
	if direction.length_squared() > 0.01:
		model.rotation.y = atan2(-direction.x, -direction.z)

func _physics_process(delta: float) -> void:
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	if not active:
		velocity = Vector3.ZERO
		return

	if block_requested and stamina > 0.0:
		blocking = true
		stamina = maxf(0.0, stamina - 55.0 * delta)
		if stamina <= 0.0:
			block_requested = false
	else:
		blocking = false
		stamina = minf(100.0, stamina + 37.0 * delta)

	block_glow.visible = blocking
	var wanted_velocity := Vector3.ZERO
	if has_destination:
		var diff := destination - global_position
		diff.y = 0.0
		if diff.length() > 0.20:
			wanted_velocity = diff.normalized() * move_speed * (0.69 if blocking else 1.0)
			var yaw := atan2(-diff.x, -diff.z)
			model.rotation.y = lerp_angle(model.rotation.y, yaw, minf(delta * 15.0, 1.0))
		else:
			has_destination = false

	velocity = velocity.move_toward(wanted_velocity, delta * 53.0)
	move_and_slide()
	var pos2 := Vector2(global_position.x, global_position.z)
	if pos2.length() > arena_radius:
		pos2 = pos2.normalized() * arena_radius
		global_position = Vector3(pos2.x, 0.0, pos2.y)

	if velocity.length_squared() > 0.75:
		walk_clock += delta * 19.0
		model.position.y = sin(walk_clock) * 0.075
	else:
		model.position.y = lerpf(model.position.y, 0.0, minf(delta * 12.0, 1.0))

func animate_attack() -> void:
	if strike_tween and strike_tween.is_running():
		strike_tween.kill()
	sword_pivot.rotation.z = 0.68
	strike_tween = create_tween()
	strike_tween.tween_property(sword_pivot, "rotation:z", -1.20, 0.115)
	strike_tween.tween_property(sword_pivot, "rotation:z", 0.0, 0.16)

func animate_hit() -> void:
	if bump_tween and bump_tween.is_running():
		bump_tween.kill()
	model.scale = Vector3.ONE
	bump_tween = create_tween()
	bump_tween.tween_property(model, "scale", Vector3(1.14, 0.88, 1.14), 0.08)
	bump_tween.tween_property(model, "scale", Vector3.ONE, 0.17)

func damage(amount: float) -> void:
	health = maxf(0.0, health - amount)
	animate_hit()
	if health <= 0.0:
		active = false
		block_requested = false
		blocking = false
		stop()

func _mat(color: Color, metallic: float = 0.0, glow: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = 0.33 if metallic > 0.0 else 0.53
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = glow
	return m

func _box(parent: Node3D, size: Vector3, position_: Vector3, material: Material) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = size
	item.mesh = box_mesh
	item.material_override = material
	item.position = position_
	parent.add_child(item)
	return item

func _sphere(parent: Node3D, radius: float, position_: Vector3, material: Material) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 12
	s.rings = 7
	item.mesh = s
	item.material_override = material
	item.position = position_
	parent.add_child(item)
	return item

func _build_toy_model() -> void:
	var marker := MeshInstance3D.new()
	var disk := CylinderMesh.new()
	disk.top_radius = 0.76
	disk.bottom_radius = 0.76
	disk.height = 0.035
	marker.mesh = disk
	marker.material_override = _mat(Color("3fe6ff") if is_player else Color("ff4b78"), 0.0, 2.0)
	marker.position.y = 0.075
	add_child(marker)

	model = Node3D.new()
	model.name = "ToyFigure"
	add_child(model)
	var plastic := _mat(Color("267bdb") if is_player else Color("8a2449"), 0.12)
	var dark := _mat(Color("19284b") if is_player else Color("302039"), 0.05)
	var trim := _mat(Color("ffd17b") if is_player else Color("e8d9e8"), 0.42)
	var skin := _mat(Color("e2c1ab") if is_player else Color("c9bcd8"), 0.0)
	var eye := _mat(Color("73ebff") if is_player else Color("ff395c"), 0.0, 2.3)

	# Проработанный силуэт игрушки: голова, туловище, ноги, руки, накладки.
	_box(model, Vector3(0.91, 0.94, 0.56), Vector3(0, 1.08, 0.0), plastic)
	_box(model, Vector3(0.99, 0.22, 0.64), Vector3(0, 1.48, 0.0), trim)
	_box(model, Vector3(0.72, 0.35, 0.53), Vector3(0, 0.64, 0.03), dark)
	for side in [-1.0, 1.0]:
		_box(model, Vector3(0.31, 0.64, 0.35), Vector3(side * 0.23, 0.35, 0.01), plastic)
		_box(model, Vector3(0.43, 0.19, 0.56), Vector3(side * 0.23, 0.12, -0.12), dark)
		_sphere(model, 0.26, Vector3(side * 0.54, 1.30, 0), trim)
		_box(model, Vector3(0.26, 0.65, 0.29), Vector3(side * 0.61, 0.95, 0), plastic)

	_sphere(model, 0.45, Vector3(0, 1.97, 0), skin if is_vampire else dark)
	for side in [-1.0, 1.0]:
		_sphere(model, 0.095, Vector3(side * 0.17, 2.02, -0.41), eye)

	if is_vampire:
		# Красный пластиковый вампир: большие воротник и плащ, характерные уши.
		_box(model, Vector3(1.20, 1.19, 0.16), Vector3(0, 1.03, 0.42), dark)
		_box(model, Vector3(1.06, 0.30, 0.50), Vector3(0, 1.61, 0.12), plastic)
		for side in [-1.0, 1.0]:
			var ear := _box(model, Vector3(0.22, 0.28, 0.19), Vector3(side * 0.46, 2.12, 0), skin)
			ear.rotation.z = side * 0.35
		_box(model, Vector3(0.44, 0.20, 0.54), Vector3(0, 2.32, 0), dark)
	else:
		# Синий пластиковый рыцарь: шлем, золотые вставки, щит и световой меч.
		_box(model, Vector3(0.94, 0.32, 0.86), Vector3(0, 2.32, 0), plastic)
		_box(model, Vector3(0.16, 0.32, 0.50), Vector3(0, 2.52, -0.05), trim)
		_box(model, Vector3(0.61, 0.15, 0.15), Vector3(0, 1.84, -0.44), trim)
		_box(model, Vector3(0.45, 0.63, 0.14), Vector3(-0.65, 1.10, -0.36), trim)

	sword_pivot = Node3D.new()
	sword_pivot.position = Vector3(0.72, 1.04, -0.31)
	model.add_child(sword_pivot)
	_box(sword_pivot, Vector3(0.13, 0.45, 0.14), Vector3(0, 0.03, 0), dark)
	_box(sword_pivot, Vector3(0.43, 0.12, 0.17), Vector3(0, 0.26, 0), trim)
	_box(sword_pivot, Vector3(0.22, 1.13, 0.11), Vector3(0, 0.84, 0), eye)
	_sphere(sword_pivot, 0.16, Vector3(0, 1.43, 0), eye)

	block_glow = _sphere(model, 0.70, Vector3(-0.57, 1.10, -0.24), _mat(Color("50d9ff") if is_player else Color("ff547b"), 0.0, 1.5))
	block_glow.scale = Vector3(0.19, 1.16, 0.21)
	block_glow.visible = false
