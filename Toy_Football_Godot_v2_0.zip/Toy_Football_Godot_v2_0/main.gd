extends Node2D

const W := 1280.0
const H := 720.0
const LEFT := 92.0
const RIGHT := 1188.0
const TOP := 92.0
const BOTTOM := 624.0
const BLUE := Color("4cc7ff")
const RED := Color("ff6575")
const WHITE := Color("f9fcff")
var font: Font
var state := "menu"
var opponent := 0 # 0 bot, 1 local
var half := 1
var time_left := 150.0
var score := [0, 0]
var players: Array = []
var ball := Vector2(640, 358)
var ball_vel := Vector2.ZERO
var selected := [2, 2]
var joy := [Vector2.ZERO, Vector2.ZERO]
var touch_joy := [-1, -1]
var touch_btn := {}
var kick_cd := [0.0, 0.0]
var bot_action := 0.0
var kickoff_pause := 0.0
var message := ""
var message_time := 0.0

func _ready() -> void:
 font = ThemeDB.fallback_font
 set_process(true)

func _start_game() -> void:
 state = "play"
 half = 1
 time_left = 150.0
 score = [0, 0]
 _reset_positions()

func _reset_positions() -> void:
 players.clear()
 for team in range(2):
  var sign := 1.0 if team == 0 else -1.0
  var cx := 640.0 - sign * 360.0
  var spots := [Vector2(cx - sign * 80.0, 358), Vector2(cx, 220), Vector2(cx, 500), Vector2(cx + sign * 155, 358)]
  for i in range(4):
   players.append({"team":team,"pos":spots[i],"vel":Vector2.ZERO,"home":spots[i],"number":i+1})
  players.append({"team":team,"pos":Vector2(125 if team == 0 else 1155, 358),"vel":Vector2.ZERO,"home":Vector2(125 if team == 0 else 1155,358),"number":0})
 ball = Vector2(640,358)
 ball_vel = Vector2.ZERO
 selected = [3,3]
 kickoff_pause = 0.65
 joy = [Vector2.ZERO,Vector2.ZERO]

func _player(team:int, i:int) -> Dictionary:
 return players[team*5+i]

func _process(delta:float) -> void:
 if state != "play":
  queue_redraw()
  return
 var dt:float = min(delta, 0.045)
 message_time = max(0.0, message_time-dt)
 if kickoff_pause > 0:
  kickoff_pause -= dt
  queue_redraw()
  return
 time_left -= dt
 if time_left <= 0:
  if half == 1:
   state = "half"
   message = "ПЕРЕРЫВ"
  else:
   state = "end"
  queue_redraw()
  return
 for t in range(2):
  kick_cd[t] = max(0.0, kick_cd[t]-dt)
 if opponent == 0:
  _bot(dt)
 for team in range(2):
  for i in range(5):
   var p:Dictionary = _player(team,i)
   var pos:Vector2 = p["pos"]
   var direction := Vector2.ZERO
   if i == 4:
    var gy:float = clamp(ball.y, 273.0, 443.0)
    direction = Vector2(0, sign(gy-pos.y)) if abs(gy-pos.y)>7 else Vector2.ZERO
    if team == 0 and selected[0] == 4:
     direction = Vector2(0,joy[0].y)
    if team == 1 and opponent == 1 and selected[1] == 4:
     direction = Vector2(0,joy[1].y)
    pos += direction*175.0*dt
    pos.x = 125 if team == 0 else 1155
    pos.y = clamp(pos.y, 270.0, 446.0)
   else:
    if i == selected[team]:
     direction = joy[team]
    else:
     var target:Vector2 = p["home"]
     var attack := (ball.x < 640.0 and team == 0) or (ball.x > 640.0 and team == 1)
     if attack and i == 3:
      target = ball + Vector2(-48 if team==0 else 48, 0)
     elif i == 0 and not attack:
      target = ball + Vector2(-65 if team==0 else 65,0)
     if pos.distance_to(target)>28:
      direction = pos.direction_to(target)*0.72
    pos += direction*245.0*dt
    pos.x = clamp(pos.x, LEFT+26, RIGHT-26)
    pos.y = clamp(pos.y, TOP+24, BOTTOM-24)
   p["pos"] = pos
   if pos.distance_to(ball)<32 and ball_vel.length()<430:
    var away:Vector2 = (ball-pos).normalized()
    if away.length_squared()<0.1:
     away = Vector2(1 if team==0 else -1,0)
    ball_vel += away*185
 ball += ball_vel*dt
 ball_vel *= pow(0.985,dt*60.0)
 if ball.y < TOP+12:
  ball.y = TOP+12
  ball_vel.y = abs(ball_vel.y)*0.83
 if ball.y > BOTTOM-12:
  ball.y = BOTTOM-12
  ball_vel.y = -abs(ball_vel.y)*0.83
 if ball.x < LEFT or ball.x > RIGHT:
  if ball.y > 284 and ball.y < 432:
   var scoring_team := 1 if ball.x<LEFT else 0
   score[scoring_team] += 1
   message = "ГОООЛ!"
   message_time = 1.2
   _reset_positions()
  else:
   ball.x = clamp(ball.x,LEFT+12,RIGHT-12)
   ball_vel.x *= -0.78
 queue_redraw()

func _bot(dt:float) -> void:
 bot_action -= dt
 var best := 0
 var distance := 99999.0
 for i in range(4):
  var d:float = (_player(1,i)["pos"] as Vector2).distance_to(ball)
  if d < distance:
   best=i
   distance=d
 selected[1]=best
 var p:Vector2 = _player(1,best)["pos"]
 joy[1] = p.direction_to(ball) if distance>20 else Vector2.ZERO
 if distance < 85 and bot_action <= 0:
  _kick(1, true)
  bot_action = 0.7

func _kick(team:int, shoot:bool) -> void:
 if state != "play" or kick_cd[team] > 0:
  return
 var p:Vector2 = _player(team,selected[team])["pos"]
 if p.distance_to(ball)>88:
  return
 var goal := Vector2(RIGHT+35 if team==0 else LEFT-35, 358)
 var direction:Vector2 = (goal-ball).normalized()
 if not shoot:
  var mate := -1
  var closest := 99999.0
  for i in range(4):
   if i==selected[team]:
    continue
   var pp:Vector2 = _player(team,i)["pos"]
   var d:float = pp.distance_to(goal)
   if d<closest:
    closest=d
    mate=i
  if mate>=0:
   direction = ball.direction_to(_player(team,mate)["pos"])
 else:
  var aim:Vector2 = joy[team]
  if aim.length()>0.35:
   direction = (direction*0.6 + aim*0.4).normalized()
 ball_vel = direction*(920 if shoot else 600)
 kick_cd[team]=0.38

func _draw() -> void:
 var sz := get_viewport_rect().size
 var scale_factor:float = min(sz.x/W,sz.y/H)
 var offset := (sz-Vector2(W,H)*scale_factor)/2.0
 draw_set_transform(offset,0,Vector2.ONE*scale_factor)
 draw_rect(Rect2(0,0,W,H),Color("101c2b"))
 if state == "menu":
  _draw_menu()
 else:
  _draw_field()
  _draw_hud()
  if state == "play":
   _draw_controls()
  if state == "half" or state == "end":
   draw_rect(Rect2(0,0,W,H),Color(0,0,0,0.72))
   var head := "ПЕРЕРЫВ" if state == "half" else "МАТЧ ОКОНЧЕН"
   _txt(head,Vector2(460,260),42,WHITE)
   _txt("%d : %d" % [score[0],score[1]],Vector2(580,345),54,WHITE)
   _button(Rect2(425,395,430,90),"ВТОРОЙ ТАЙМ" if state=="half" else "ГЛАВНОЕ МЕНЮ",Color("247db8"))
 draw_set_transform(Vector2.ZERO,0,Vector2.ONE)

func _draw_field() -> void:
 draw_rect(Rect2(LEFT-20,TOP-18,RIGHT-LEFT+40,BOTTOM-TOP+36),Color("4b3325"))
 draw_rect(Rect2(LEFT,TOP,RIGHT-LEFT,BOTTOM-TOP),Color("22864d"))
 for i in range(10):
  if i%2==0:
   draw_rect(Rect2(LEFT+i*(RIGHT-LEFT)/10.0,TOP,(RIGHT-LEFT)/10.0,BOTTOM-TOP),Color("299657"))
 draw_rect(Rect2(LEFT,TOP,RIGHT-LEFT,BOTTOM-TOP),WHITE,false,4)
 draw_line(Vector2(640,TOP),Vector2(640,BOTTOM),WHITE,3)
 draw_arc(Vector2(640,358),78,0,TAU,64,WHITE,3)
 draw_circle(Vector2(640,358),5,WHITE)
 draw_rect(Rect2(LEFT,222,175,272),WHITE,false,3)
 draw_rect(Rect2(RIGHT-175,222,175,272),WHITE,false,3)
 draw_rect(Rect2(LEFT-25,284,25,148),Color("e2f5ff"),false,4)
 draw_rect(Rect2(RIGHT,284,25,148),Color("e2f5ff"),false,4)
 for team in range(2):
  for i in range(5):
   var p:Vector2 = _player(team,i)["pos"]
   var c:Color = BLUE if team==0 else RED
   draw_circle(p+Vector2(4,6),23,Color(0,0,0,0.24))
   draw_circle(p,21,c)
   draw_circle(p-Vector2(5,7),7,Color(1,1,1,0.4))
   if selected[team]==i:
    draw_arc(p,27,0,TAU,48,Color("ffdf61"),4)
   _txt(str(i+1) if i<4 else "G",p+Vector2(-8,7),19,Color("152b3d"))
 draw_circle(ball+Vector2(4,5),13,Color(0,0,0,0.25))
 draw_circle(ball,13,WHITE)
 draw_circle(ball+Vector2(-4,-4),5,Color("222e3a"))

func _draw_hud() -> void:
 draw_rect(Rect2(405,9,470,69),Color("0c1827"))
 _txt("СИНИЕ",Vector2(424,52),20,BLUE)
 _txt("%d : %d" % [score[0],score[1]],Vector2(576,55),38,WHITE)
 _txt("КРАСНЫЕ",Vector2(739,52),20,RED)
 _txt("%d ТАЙМ  %02d:%02d" % [half,int(ceil(time_left))/60,int(ceil(time_left))%60],Vector2(507,86),17,WHITE)
 if message_time>0:
  _txt(message,Vector2(540,170),44,Color("ffe16a"))

func _draw_menu() -> void:
 _txt("TOY FOOTBALL 2.0",Vector2(340,142),60,WHITE)
 _txt("АРКАДНЫЙ ФУТБОЛ • 2 ТАЙМА ПО 2:30",Vector2(360,201),24,Color("a5bdd1"))
 _txt("ВЫБЕРИ СОПЕРНИКА",Vector2(492,280),24,WHITE)
 _button(Rect2(310,319,660,91),"ПРОТИВ БОТА" + ("  ✓" if opponent==0 else ""),Color("1778ac") if opponent==0 else Color("344c62"))
 _button(Rect2(310,426,660,91),"ДВА ИГРОКА" + ("  ✓" if opponent==1 else ""),Color("1778ac") if opponent==1 else Color("344c62"))
 _button(Rect2(430,550,420,95),"ИГРАТЬ ▶",Color("e2a437"))

func _draw_controls() -> void:
 var blue_origin := Vector2(110,647)
 var red_origin := Vector2(760,647) if opponent==1 else Vector2(-500,-500)
 for t in range(2 if opponent==1 else 1):
  var origin := blue_origin if t==0 else red_origin
  draw_circle(origin,58,Color(0.08,0.13,0.2,0.75))
  draw_arc(origin,58,0,TAU,48,BLUE if t==0 else RED,3)
  draw_circle(origin+joy[t]*31,24,Color("d9e9f2"))
 var bx := 1115.0 if opponent==0 else 520.0
 var rx := 1160.0
 _control_button(Vector2(bx,647),"УДАР",Color("e9a83a"))
 _control_button(Vector2(bx-120,647),"ПАС",Color("438acb"))
 _control_button(Vector2(bx-240,647),"СМЕНА",Color("58728c"))
 if opponent==1:
  _control_button(Vector2(rx,647),"УДАР",Color("e9a83a"))
  _control_button(Vector2(rx-120,647),"ПАС",Color("438acb"))
  _control_button(Vector2(rx-240,647),"СМЕНА",Color("58728c"))

func _control_button(p:Vector2,label:String,color:Color) -> void:
 draw_circle(p,45,Color(0,0,0,0.35))
 draw_circle(p,41,color)
 _txt(label,p+Vector2(-29,7),16,WHITE)

func _button(r:Rect2,label:String,c:Color) -> void:
 draw_rect(r,c)
 draw_rect(r,Color("b4e5ff"),false,3)
 _txt(label,Vector2(r.position.x+35,r.position.y+r.size.y/2+13),32,WHITE)

func _txt(s:String,p:Vector2,size:int,c:Color) -> void:
 draw_string(font,p,s,HORIZONTAL_ALIGNMENT_LEFT,-1,size,c)

func _input(event:InputEvent) -> void:
 var sz := get_viewport_rect().size
 var factor:float = min(sz.x/W,sz.y/H)
 var ofs := (sz-Vector2(W,H)*factor)/2.0
 if event is InputEventScreenTouch:
  var pos:Vector2 = (event.position-ofs)/factor
  if event.pressed:
   _press(pos,event.index)
  else:
   _release(event.index)
 elif event is InputEventScreenDrag:
  var pos:Vector2 = (event.position-ofs)/factor
  for t in range(2):
   if touch_joy[t]==event.index:
    var origin := Vector2(110,647) if t==0 else Vector2(760,647)
    joy[t] = ((pos-origin)/58.0).limit_length(1.0)
 elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
  var pos:Vector2 = (event.position-ofs)/factor
  if event.pressed:
   _press(pos,99)
  else:
   _release(99)
 elif event is InputEventMouseMotion:
  for t in range(2):
   if touch_joy[t]==99:
    var origin := Vector2(110,647) if t==0 else Vector2(760,647)
    joy[t] = (((event.position-ofs)/factor-origin)/58.0).limit_length(1.0)

func _press(pos:Vector2,id:int) -> void:
 if state=="menu":
  if Rect2(310,319,660,91).has_point(pos):
   opponent=0
  elif Rect2(310,426,660,91).has_point(pos):
   opponent=1
  elif Rect2(430,550,420,95).has_point(pos):
   _start_game()
 elif state=="half" or state=="end":
  if Rect2(425,395,430,90).has_point(pos):
   if state=="half":
    half=2
    time_left=150.0
    _reset_positions()
    state="play"
   else:
    state="menu"
 elif state=="play":
  if pos.distance_to(Vector2(110,647))<90:
   touch_joy[0]=id
   joy[0]=((pos-Vector2(110,647))/58.0).limit_length(1.0)
  elif opponent==1 and pos.distance_to(Vector2(760,647))<90:
   touch_joy[1]=id
   joy[1]=((pos-Vector2(760,647))/58.0).limit_length(1.0)
  else:
   var team := 1 if opponent==1 and pos.x>640 else 0
   var bx := (1115.0 if opponent==0 else 1160.0) if team==1 or opponent==0 else 520.0
   if pos.distance_to(Vector2(bx,647))<50:
    _kick(team,true)
   elif pos.distance_to(Vector2(bx-120,647))<50:
    _kick(team,false)
   elif pos.distance_to(Vector2(bx-240,647))<50:
    selected[team]=(selected[team]+1)%4
 queue_redraw()

func _release(id:int) -> void:
 for t in range(2):
  if touch_joy[t]==id:
   touch_joy[t]=-1
   joy[t]=Vector2.ZERO
