extends Node2D

const LEFT := 90.0
const RIGHT := 1190.0
const TOP := 130.0
const BOTTOM := 615.0
const MID := 372.5
const ZONE := 185.0
const KICK := 850.0
var ball := Vector2(640, MID)
var ball_speed := Vector2.ZERO
var figures: Array[Dictionary] = []
var blue := 0
var red := 0
var remaining := 120.0
var mode := 0 # 0=time, 1=first to ten
var opponent := 0 # 0=bot, 1=two players
var phase := 0 # 0=menu, 1=playing, 2=finished
var goal_pause := 0.0
var bot_timer := 0.5
var message := ""
var message_timer := 0.0
var font: Font

func _ready() -> void:
    font = ThemeDB.fallback_font
    _reset_field()
    queue_redraw()

func _reset_field() -> void:
    figures.clear()
    var homes := [Vector2(215, MID), Vector2(425, 235), Vector2(425, 510), Vector2(1065, MID), Vector2(855, 235), Vector2(855, 510)]
    for i in range(6):
        var h: Vector2 = homes[i]
        figures.append({"team": int(i / 3), "home": h, "pos": h, "dash": false, "cool": 0.0})
    ball = Vector2(640, MID)
    ball_speed = Vector2.ZERO

func _start() -> void:
    blue = 0
    red = 0
    remaining = 120.0
    phase = 1
    goal_pause = 0.0
    bot_timer = 0.5
    message = ""
    _reset_field()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _tap(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _tap(event.position)

func _tap(p: Vector2) -> void:
    if phase == 0:
        if p.y >= 275.0 and p.y < 360.0:
            opponent = 1 - opponent
        elif p.y >= 370.0 and p.y < 455.0:
            mode = 1 - mode
        elif p.y >= 465.0 and p.y < 580.0:
            _start()
    elif phase == 2:
        phase = 0
    elif phase == 1 and goal_pause <= 0.0:
        var team := 0 if p.x < 640.0 else 1
        if opponent == 0 and team == 1:
            return
        _activate(team, p)

func _activate(team: int, at: Vector2) -> void:
    var closest := -1
    var distance := 115.0
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        if f["team"] != team or f["cool"] > 0.0:
            continue
        var d: float = (f["pos"] as Vector2).distance_to(at)
        if d < distance:
            closest = i
            distance = d
    if closest >= 0:
        figures[closest]["dash"] = true
        figures[closest]["cool"] = 0.52

func _process(delta: float) -> void:
    var dt := minf(delta, 0.05)
    if message_timer > 0.0:
        message_timer -= dt
    if phase == 1:
        _simulate(dt)
    queue_redraw()

func _simulate(dt: float) -> void:
    if goal_pause > 0.0:
        goal_pause -= dt
        if goal_pause <= 0.0:
            _reset_field()
        return
    if mode == 0:
        remaining -= dt
        if remaining <= 0.0:
            phase = 2
            return
    if opponent == 0:
        bot_timer -= dt
        if bot_timer <= 0.0:
            bot_timer = randf_range(0.22, 0.42)
            var chosen := -1
            var best := 999999.0
            for i in range(3, 6):
                var f: Dictionary = figures[i]
                var d: float = (f["home"] as Vector2).distance_to(ball)
                if d < ZONE + 60.0 and d < best and f["cool"] <= 0.0:
                    best = d
                    chosen = i
            if chosen >= 0:
                figures[chosen]["dash"] = true
                figures[chosen]["cool"] = 0.55
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        f["cool"] = maxf(0.0, float(f["cool"]) - dt)
        var home: Vector2 = f["home"]
        var pos: Vector2 = f["pos"]
        var target := home
        if f["dash"]:
            target = home + (ball - home).limit_length(ZONE)
        pos = pos.move_toward(target, (630.0 if f["dash"] else 360.0) * dt)
        f["pos"] = pos
        if f["dash"] and pos.distance_to(ball) < 47.0:
            var goal := Vector2(RIGHT if f["team"] == 0 else LEFT, MID)
            var direction := (goal - ball).normalized()
            ball_speed = direction.rotated(randf_range(-0.12, 0.12)) * KICK
            f["dash"] = false
            message = "УДАР!"
            message_timer = 0.25
        elif f["dash"] and pos.distance_to(target) < 4.0:
            f["dash"] = false
        if pos.distance_to(ball) < 33.0 and ball_speed.length() > 30.0:
            ball_speed = (ball - pos).normalized() * maxf(ball_speed.length() * 0.8, 140.0)
        figures[i] = f
    ball += ball_speed * dt
    ball_speed = ball_speed.move_toward(Vector2.ZERO, 135.0 * dt)
    if ball.y < TOP + 17.0:
        ball.y = TOP + 17.0
        ball_speed.y = absf(ball_speed.y) * 0.83
    elif ball.y > BOTTOM - 17.0:
        ball.y = BOTTOM - 17.0
        ball_speed.y = -absf(ball_speed.y) * 0.83
    if ball.x < LEFT or ball.x > RIGHT:
        if absf(ball.y - MID) < 80.0:
            if ball.x > RIGHT:
                blue += 1
            else:
                red += 1
            message = "ГОООЛ!"
            message_timer = 1.5
            goal_pause = 1.5
            ball_speed = Vector2.ZERO
            if mode == 1 and (blue >= 10 or red >= 10):
                phase = 2
        else:
            ball.x = clampf(ball.x, LEFT, RIGHT)
            ball_speed.x *= -0.83

func _text(s: String, at: Vector2, size: int = 28, tint: Color = Color.WHITE) -> void:
    var w := font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
    draw_string(font, at - Vector2(w * 0.5, 0), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, tint)

func _draw() -> void:
    draw_rect(Rect2(0, 0, 1280, 720), Color("#142136"))
    draw_rect(Rect2(60, 98, 1160, 558), Color("#33495d"))
    draw_rect(Rect2(LEFT - 9, TOP - 9, RIGHT - LEFT + 18, BOTTOM - TOP + 18), Color("#9cb4b7"))
    draw_rect(Rect2(LEFT, TOP, RIGHT - LEFT, BOTTOM - TOP), Color("#298f59"))
    for i in range(10):
        if i % 2 == 0:
            draw_rect(Rect2(LEFT + i * 110, TOP, 110, BOTTOM - TOP), Color(1, 1, 1, 0.05))
    var line := Color("#e6fff0")
    draw_rect(Rect2(LEFT, TOP, RIGHT - LEFT, BOTTOM - TOP), line, false, 4)
    draw_line(Vector2(640, TOP), Vector2(640, BOTTOM), line, 3)
    draw_arc(Vector2(640, MID), 82, 0, TAU, 64, line, 3)
    draw_circle(Vector2(640, MID), 5, line)
    draw_rect(Rect2(LEFT, MID - 115, 150, 230), line, false, 3)
    draw_rect(Rect2(RIGHT - 150, MID - 115, 150, 230), line, false, 3)
    draw_rect(Rect2(LEFT - 35, MID - 80, 35, 160), Color("#d7e3f0"))
    draw_rect(Rect2(RIGHT, MID - 80, 35, 160), Color("#d7e3f0"))
    for f in figures:
        var pos: Vector2 = f["pos"]
        var col := Color("#2688f2") if f["team"] == 0 else Color("#ed5355")
        draw_circle(pos + Vector2(4, 9), 31, Color(0, 0, 0, 0.28))
        draw_circle(pos, 30, Color("#e4d4ad"))
        draw_circle(pos + Vector2(0, -5), 23, col)
        draw_circle(pos + Vector2(-6, -12), 10, Color("#ffdfae"))
        draw_circle(pos + Vector2(-9, -14), 2, Color("#1b2c40"))
        draw_circle(pos + Vector2(-3, -14), 2, Color("#1b2c40"))
        draw_arc(pos, 34, 0, TAU, 28, Color(1, 1, 1, 0.45), 2)
        if f["dash"]:
            draw_arc(f["home"], ZONE, 0, TAU, 48, Color(1, 1, 1, 0.2), 2)
    draw_circle(ball + Vector2(3, 6), 18, Color(0, 0, 0, 0.3))
    draw_circle(ball, 16, Color.WHITE)
    draw_circle(ball + Vector2(-3, -4), 6, Color("#283547"))
    draw_circle(ball + Vector2(8, 5), 4, Color("#283547"))
    draw_rect(Rect2(0, 0, 1280, 92), Color("#142136"))
    _text("СИНИЕ  %d : %d  КРАСНЫЕ" % [blue, red], Vector2(640, 41), 35)
    var timer := "ДО 10 ГОЛОВ"
    if mode == 0:
        var sec := int(ceil(remaining))
        timer = "%02d:%02d" % [int(sec / 60), sec % 60]
    _text(timer, Vector2(640, 80), 24, Color("#ffdfa0"))
    if message_timer > 0.0:
        _text(message, Vector2(640, 125), 37, Color("#ffdf72"))
    if phase == 0:
        draw_rect(Rect2(270, 158, 740, 452), Color("#142136"))
        _text("TOY FOOTBALL", Vector2(640, 239), 56, Color("#ffe18a"))
        draw_rect(Rect2(355, 275, 570, 84), Color("#305d83"))
        _text("СОПЕРНИК: БОТ" if opponent == 0 else "СОПЕРНИК: 2 ИГРОКА", Vector2(640, 332), 30)
        draw_rect(Rect2(355, 370, 570, 84), Color("#305d83"))
        _text("РЕЖИМ: 2 МИНУТЫ" if mode == 0 else "РЕЖИМ: ДО 10 ГОЛОВ", Vector2(640, 427), 30)
        draw_rect(Rect2(355, 465, 570, 110), Color("#39a869"))
        _text("ИГРАТЬ", Vector2(640, 538), 46)
    elif phase == 2:
        draw_rect(Rect2(265, 220, 750, 300), Color("#142136"))
        var result := "НИЧЬЯ!" if blue == red else ("ПОБЕДА СИНИХ!" if blue > red else "ПОБЕДА КРАСНЫХ!")
        _text(result, Vector2(640, 336), 51, Color("#ffe18a"))
        _text("НАЖМИТЕ ДЛЯ НОВОЙ ИГРЫ", Vector2(640, 436), 30)
    else:
        _text("НАЖИМАЙ НА СВОИХ ФУТБОЛИСТОВ", Vector2(640, 691), 24, Color("#dbeaf4"))
