extends Node2D

# Toy Football 0.3. Two-player multitouch / bot; no 3D renderer needed.
const L := 92.0
const R := 1188.0
const T := 126.0
const B := 625.0
const CY := 375.0
const GT := 295.0
const GB := 455.0
const PLAYER_SPEED := 540.0
const SHOT_SPEED := 950.0
var ball := Vector2(640, CY)
var ball_vel := Vector2.ZERO
var figures: Array[Dictionary] = []
var blue := 0
var red := 0
var remaining := 240.0
var mode := 0 # 0=4 minutes; 1=first to 10 goals
var opponent := 0 # 0=bot; 1=2 people
var phase := 0 # 0 menu; 1 playing; 2 finished
var goal_pause := 0.0
var bot_timer := 0.3
var message := ""
var message_timer := 0.0
var idle_timer := 0.0
var font: Font

func _ready() -> void:
    font = ThemeDB.fallback_font
    _reset_field()
    queue_redraw()

func _reset_field() -> void:
    figures.clear()
    for team in range(2):
        var sign := 1.0 if team == 0 else -1.0
        var positions := [
            Vector2(150.0, CY),
            Vector2(345.0, 265.0), Vector2(345.0, 485.0),
            Vector2(520.0, 205.0), Vector2(520.0, CY), Vector2(520.0, 545.0),
            Vector2(600.0, 290.0), Vector2(600.0, 460.0)
        ]
        for j in range(positions.size()):
            var p: Vector2 = positions[j]
            var home := Vector2(p.x if team == 0 else 1280.0-p.x,p.y)
            var role := 0 if j == 0 else (1 if j <= 2 else (2 if j <= 5 else 3))
            figures.append({"team":team,"role":role,"home":home,"pos":home,"target":home,"active":false,"cool":0.0,"dir":sign})
    ball = Vector2(640.0,CY)
    ball_vel = Vector2.ZERO
    idle_timer = 0.0

func _start() -> void:
    blue = 0
    red = 0
    remaining = 240.0
    phase = 1
    goal_pause = 0.0
    bot_timer = 0.3
    message = ""
    _reset_field()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        _tap(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _tap(event.position)

func _tap(p: Vector2) -> void:
    if phase == 0:
        if p.y >= 274.0 and p.y < 359.0:
            opponent = 1 - opponent
        elif p.y >= 367.0 and p.y < 454.0:
            mode = 1 - mode
        elif p.y >= 467.0 and p.y < 580.0:
            _start()
    elif phase == 2:
        phase = 0
    elif phase == 1 and goal_pause <= 0.0:
        var team := 0 if p.x < 640.0 else 1
        if opponent == 0 and team == 1:
            return
        _activate(team,p)

func _activate(team: int, at: Vector2) -> void:
    var selected := -1
    var best := 110.0
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        if f["team"] != team or f["cool"] > 0.0:
            continue
        var distance: float = (f["pos"] as Vector2).distance_to(at)
        if distance < best:
            selected = i
            best = distance
    if selected >= 0:
        figures[selected]["active"] = true
        figures[selected]["cool"] = 0.38
        # A touch instantly kicks a ball already inside the figure's reachable zone.
        var f: Dictionary = figures[selected]
        if (f["pos"] as Vector2).distance_to(ball) < 94.0:
            _kick(team, f["pos"])
            figures[selected]["active"] = false

func _process(delta: float) -> void:
    var dt := minf(delta,0.045)
    if message_timer > 0.0:
        message_timer -= dt
    if phase == 1:
        _simulate(dt)
    queue_redraw()

func _reachable(f: Dictionary, target: Vector2) -> Vector2:
    var home: Vector2 = f["home"]
    if f["role"] == 0:
        return Vector2(home.x,clampf(target.y,GT+22.0,GB-22.0))
    var max_x := 100.0 if f["role"] == 1 else 125.0
    var max_y := 142.0 if f["role"] == 1 else 164.0
    return Vector2(clampf(target.x,home.x-max_x,home.x+max_x),clampf(target.y,home.y-max_y,home.y+max_y))

func _kick(team: int, from: Vector2) -> void:
    var direction := 1.0 if team == 0 else -1.0
    var goal := Vector2(R+22.0 if team == 0 else L-22.0,CY)
    var aim: Vector2 = (goal-ball).normalized()
    # Blend goal-directed shooting with the player's current approach angle.
    var approach: Vector2 = (ball-from).normalized()
    var shot: Vector2 = (aim*0.82+approach*0.18).normalized()
    if shot.length_squared() < 0.01:
        shot = Vector2(direction,0)
    ball_vel = shot*SHOT_SPEED
    message = "УДАР!"
    message_timer = 0.32
    idle_timer = 0.0

func _simulate(dt: float) -> void:
    if goal_pause > 0.0:
        goal_pause -= dt
        if goal_pause <= 0.0 and phase == 1:
            _reset_field()
        return
    if mode == 0:
        remaining -= dt
        if remaining <= 0.0:
            remaining = 0.0
            phase = 2
            return
    if opponent == 0:
        bot_timer -= dt
        if bot_timer <= 0.0:
            bot_timer = randf_range(0.22,0.43)
            var candidate := -1
            var best := 99999.0
            for i in range(figures.size()):
                var f: Dictionary = figures[i]
                if f["team"] != 1 or f["cool"] > 0.0:
                    continue
                var reachable: Vector2 = _reachable(f,ball)
                var dist := reachable.distance_to(ball)
                if dist < best:
                    best = dist
                    candidate = i
            if candidate >= 0 and best < 160.0:
                figures[candidate]["active"] = true
                figures[candidate]["cool"] = 0.55
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        f["cool"] = maxf(0.0,float(f["cool"])-dt)
        var home: Vector2 = f["home"]
        var pos: Vector2 = f["pos"]
        var target := home
        if f["role"] == 0:
            # Goalkeepers patrol vertically to block shots automatically.
            target = _reachable(f,ball)
        elif f["active"]:
            target = _reachable(f,ball)
        pos = pos.move_toward(target,PLAYER_SPEED*dt if f["active"] or f["role"] == 0 else PLAYER_SPEED*0.65*dt)
        f["pos"] = pos
        if f["active"] and pos.distance_to(ball) < 75.0:
            _kick(int(f["team"]),pos)
            f["active"] = false
        elif f["active"] and pos.distance_to(target) < 5.0:
            # Ball outside the lane? Strike toward it if close enough to the lane.
            if pos.distance_to(ball) < 135.0:
                _kick(int(f["team"]),pos)
            f["active"] = false
        # Keeper can block without taps, field figures deflect ball on collision.
        if pos.distance_to(ball) < 31.0:
            if f["role"] == 0:
                _kick(int(f["team"]),pos)
            elif ball_vel.length() > 20.0:
                ball_vel = (ball-pos).normalized()*maxf(ball_vel.length()*0.80,210.0)
        figures[i] = f
    ball += ball_vel*dt
    ball_vel = ball_vel.move_toward(Vector2.ZERO,135.0*dt)
    if ball.y < T+14.0:
        ball.y = T+14.0
        ball_vel.y = absf(ball_vel.y)*0.88
    elif ball.y > B-14.0:
        ball.y = B-14.0
        ball_vel.y = -absf(ball_vel.y)*0.88
    if ball.x < L or ball.x > R:
        if ball.y > GT and ball.y < GB:
            if ball.x > R:
                blue += 1
            else:
                red += 1
            message = "ГОООЛ!"
            message_timer = 1.3
            ball_vel = Vector2.ZERO
            goal_pause = 1.3
            if mode == 1 and (blue >= 10 or red >= 10):
                phase = 2
        else:
            ball.x = clampf(ball.x,L,R)
            ball_vel.x *= -0.9
    idle_timer += dt
    # Prevent a deadlocked midfield: nudge stationary balls into a reachable lane.
    if ball_vel.length() < 24.0 and idle_timer > 2.0:
        ball_vel = Vector2(randf_range(-1.0,1.0),randf_range(-0.55,0.55)).normalized()*260.0
        idle_timer = 0.0
    elif ball_vel.length() > 40.0:
        idle_timer = 0.0

func _label(text: String, at: Vector2, size: int, color: Color = Color.WHITE) -> void:
    var width := font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
    draw_string(font,at-Vector2(width/2.0,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw() -> void:
    draw_rect(Rect2(0,0,1280,720),Color("#111c2d"))
    draw_rect(Rect2(62,100,1156,554),Color("#31465c"))
    draw_rect(Rect2(L-8,T-8,R-L+16,B-T+16),Color("#d9e6df"))
    draw_rect(Rect2(L,T,R-L,B-T),Color("#29945f"))
    for i in range(10):
        if i%2==0:
            draw_rect(Rect2(L+i*(R-L)/10.0,T,(R-L)/10.0,B-T),Color(1,1,1,0.035))
    var white := Color("#e9ffef")
    draw_rect(Rect2(L,T,R-L,B-T),white,false,3.0)
    draw_line(Vector2(640,T),Vector2(640,B),white,3.0)
    draw_arc(Vector2(640,CY),80,0,TAU,64,white,3.0)
    draw_rect(Rect2(L,260,140,230),white,false,3.0)
    draw_rect(Rect2(R-140,260,140,230),white,false,3.0)
    draw_rect(Rect2(L-29,GT,29,GB-GT),Color("#dbe5ed"))
    draw_rect(Rect2(R,GT,29,GB-GT),Color("#dbe5ed"))
    # Distinct rows visually resemble a tabletop football formation.
    for f in figures:
        var pos: Vector2 = f["pos"]
        var color := Color("#318bf4") if f["team"] == 0 else Color("#ef5554")
        draw_circle(pos+Vector2(3,7),24,Color(0,0,0,0.26))
        draw_circle(pos,24,Color("#ead9b3"))
        draw_circle(pos+Vector2(0,-3),19,color)
        draw_circle(pos+Vector2(-4,-8),8,Color("#ffe4bd"))
        draw_circle(pos+Vector2(-7,-9),1.9,Color("#223148"))
        draw_circle(pos+Vector2(-2,-9),1.9,Color("#223148"))
        draw_arc(pos,26,0,TAU,24,Color(1,1,1,0.35),2)
        if f["active"]:
            draw_arc(pos,32,0,TAU,28,Color("#ffe27d"),3)
    draw_circle(ball+Vector2(3,5),14,Color(0,0,0,0.22))
    draw_circle(ball,13,Color.WHITE)
    draw_circle(ball+Vector2(-3,-3),5,Color("#25344a"))
    draw_circle(ball+Vector2(6,4),3,Color("#25344a"))
    draw_rect(Rect2(0,0,1280,89),Color("#111c2d"))
    _label("СИНИЕ  %d : %d  КРАСНЫЕ" % [blue,red],Vector2(640,40),36)
    if mode == 0:
        var secs := int(ceil(remaining))
        _label("%02d:%02d" % [int(secs/60),secs%60],Vector2(640,77),25,Color("#ffe09c"))
    else:
        _label("ПЕРВЫЙ ДО 10 ГОЛОВ",Vector2(640,77),24,Color("#ffe09c"))
    if message_timer > 0:
        _label(message,Vector2(640,117),32,Color("#ffe27d"))
    if phase == 0:
        draw_rect(Rect2(260,159,760,445),Color("#102138"))
        _label("TOY FOOTBALL 0.3",Vector2(640,240),52,Color("#ffdf86"))
        draw_rect(Rect2(350,274,580,84),Color("#2b577e"))
        _label("ПРОТИВ БОТА" if opponent == 0 else "ДВА ИГРОКА",Vector2(640,328),33)
        draw_rect(Rect2(350,367,580,87),Color("#2b577e"))
        _label("4 МИНУТЫ" if mode == 0 else "ДО 10 ГОЛОВ",Vector2(640,423),33)
        draw_rect(Rect2(350,467,580,112),Color("#36a66a"))
        _label("ИГРАТЬ",Vector2(640,539),47)
    elif phase == 2:
        draw_rect(Rect2(268,214,744,290),Color("#102138"))
        var result := "НИЧЬЯ!" if blue == red else ("ПОБЕДА СИНИХ!" if blue > red else "ПОБЕДА КРАСНЫХ!")
        _label(result,Vector2(640,333),48,Color("#ffe08c"))
        _label("НАЖМИ ДЛЯ НОВОГО МАТЧА",Vector2(640,421),31)
    else:
        _label("КАСАЙСЯ ФИГУРОК — ОНИ ДВИГАЮТСЯ И БЬЮТ ПО МЯЧУ",Vector2(640,689),21,Color("#dbe9ef"))
