extends Node2D

# Toy Football 0.3. Two-player multitouch / bot; no 3D renderer needed.
const L := 92.0
const R := 1188.0
const T := 126.0
const B := 625.0
const CY := 375.0
const GT := 295.0
const GB := 455.0
const PLAYER_SPEED := 540.0
const SHOT_SPEED := 950.0
var ball := Vector2(640, CY)
var ball_vel := Vector2.ZERO
var figures: Array[Dictionary] = []
var blue := 0
var red := 0
var remaining := 240.0
var mode := 0 # 0=4 minutes; 1=first to 10 goals
var opponent := 0 # 0=bot; 1=2 people
var phase := 0 # 0 menu; 1 playing; 2 finished
var goal_pause := 0.0
var bot_timer := 0.3
var message := ""
var message_timer := 0.0
var idle_timer := 0.0
var font: Font

func _ready() -> void:
    font = ThemeDB.fallback_font
    _reset_field()
    queue_redraw()

var selected := -1
var aim_start := Vector2.ZERO
var aim_now := Vector2.ZERO
var aiming := false
var move_vel: Array[Vector2] = []
var bot_delay := 0.85
var bot_aim := Vector2.ZERO

func _reset_field() -> void:
    figures.clear()
    move_vel.clear()
    for team in range(2):
        var positions := [Vector2(170,CY),Vector2(340,245),Vector2(340,505),Vector2(505,270),Vector2(505,480)]
        for j in range(5):
            var h: Vector2 = positions[j]
            if team == 1:
                h.x = 1280.0-h.x
            figures.append({"team":team,"role":j,"home":h,"pos":h,"cool":0.0})
            move_vel.append(Vector2.ZERO)
    ball = Vector2(640,CY)
    ball_vel = Vector2.ZERO
    selected = -1
    aiming = false
    bot_delay = 0.8
    idle_timer = 0.0

func _start() -> void:
    blue = 0
    red = 0
    remaining = 240.0
    phase = 1
    goal_pause = 0.0
    bot_timer = 0.3
    message = ""
    _reset_field()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _press(event.position)
        else:
            _release(event.position)
    elif event is InputEventScreenDrag and aiming:
        aim_now = event.position
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _press(event.position)
        else:
            _release(event.position)
    elif event is InputEventMouseMotion and aiming:
        aim_now = event.position

func _press(p: Vector2) -> void:
    if phase == 0:
        if p.y >= 274.0 and p.y < 359.0:
            opponent = 1-opponent
        elif p.y >= 367.0 and p.y < 454.0:
            mode = 1-mode
        elif p.y >= 467.0 and p.y < 580.0:
            _start()
        return
    if phase == 2:
        phase = 0
        return
    if phase != 1 or goal_pause > 0:
        return
    var best := 54.0
    selected = -1
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        if opponent == 0 and f["team"] != 0:
            continue
        var d: float = (f["pos"] as Vector2).distance_to(p)
        if d < best and move_vel[i].length() < 60:
            best=d
            selected=i
    if selected >= 0:
        aiming = true
        aim_start = p
        aim_now = p

func _release(p: Vector2) -> void:
    if not aiming:
        return
    aiming = false
    if selected >= 0:
        var pull := (aim_start-p).limit_length(145.0)
        if pull.length() > 12:
            move_vel[selected] = pull*6.4
    selected = -1

func _process(delta: float) -> void:
    var dt := minf(delta,0.045)
    if message_timer > 0.0:
        message_timer -= dt
    if phase == 1:
        _simulate(dt)
    queue_redraw()

func _simulate(dt: float) -> void:
    if goal_pause > 0:
        goal_pause -= dt
        if goal_pause <= 0 and phase == 1:
            _reset_field()
        return
    if mode == 0:
        remaining -= dt
        if remaining <= 0:
            remaining = 0
            phase = 2
            return
    # Bot shoots with a modest delay, never moves the human goalkeeper.
    if opponent == 0:
        bot_delay -= dt
        if bot_delay <= 0:
            bot_delay = randf_range(0.9,1.5)
            var nearest := -1
            var best := 999999.0
            for i in range(5,10):
                var f: Dictionary = figures[i]
                var d: float = (f["pos"] as Vector2).distance_to(ball)
                if d < best and move_vel[i].length() < 45:
                    best=d
                    nearest=i
            if nearest >= 0:
                var f: Dictionary = figures[nearest]
                var toward: Vector2 = (ball-(f["pos"] as Vector2)).normalized()
                move_vel[nearest] = toward*randf_range(410,630)
    for i in range(figures.size()):
        var f: Dictionary = figures[i]
        var pos: Vector2 = f["pos"]
        var v: Vector2 = move_vel[i]
        pos += v*dt
        v = v.move_toward(Vector2.ZERO,530*dt)
        # The keeper is manually controlled and moves ONLY along its goal line.
        if f["role"] == 0:
            pos.x = (f["home"] as Vector2).x
            pos.y = clampf(pos.y,GT+28,GB-28)
            v.x = 0
        else:
            pos.x = clampf(pos.x,L+24,R-24)
            pos.y = clampf(pos.y,T+24,B-24)
        if pos.distance_to(ball) < 36:
            var normal: Vector2 = (ball-pos).normalized()
            if normal.length_squared() < 0.01:
                normal = Vector2.RIGHT if f["team"] == 0 else Vector2.LEFT
            ball = pos+normal*36
            ball_vel = normal*maxf(v.length()*1.65,ball_vel.length()*0.75+95)
            v *= 0.3
        f["pos"] = pos
        figures[i] = f
        move_vel[i] = v
    ball += ball_vel*dt
    ball_vel = ball_vel.move_toward(Vector2.ZERO,145*dt)
    if ball.y < T+14:
        ball.y = T+14
        ball_vel.y = absf(ball_vel.y)*0.84
    elif ball.y > B-14:
        ball.y = B-14
        ball_vel.y = -absf(ball_vel.y)*0.84
    if ball.x < L or ball.x > R:
        if ball.y > GT and ball.y < GB:
            if ball.x > R:
                blue += 1
            else:
                red += 1
            message = "ГОООЛ!"
            message_timer = 1.4
            goal_pause = 1.4
            ball_vel = Vector2.ZERO
            if mode == 1 and (blue >= 10 or red >= 10):
                phase = 2
        else:
            ball.x = clampf(ball.x,L,R)
            ball_vel.x *= -0.84
    # No random ball kicks: players have full control of the match.

func _label(text: String, at: Vector2, size: int, color: Color = Color.WHITE) -> void:
    var width := font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
    draw_string(font,at-Vector2(width/2.0,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw() -> void:
    draw_rect(Rect2(0,0,1280,720),Color("#111c2d"))
    draw_rect(Rect2(62,100,1156,554),Color("#31465c"))
    draw_rect(Rect2(L-8,T-8,R-L+16,B-T+16),Color("#d9e6df"))
    draw_rect(Rect2(L,T,R-L,B-T),Color("#29945f"))
    for i in range(10):
        if i%2==0:
            draw_rect(Rect2(L+i*(R-L)/10.0,T,(R-L)/10.0,B-T),Color(1,1,1,0.035))
    var white := Color("#e9ffef")
    draw_rect(Rect2(L,T,R-L,B-T),white,false,3.0)
    draw_line(Vector2(640,T),Vector2(640,B),white,3.0)
    draw_arc(Vector2(640,CY),80,0,TAU,64,white,3.0)
    draw_rect(Rect2(L,260,140,230),white,false,3.0)
    draw_rect(Rect2(R-140,260,140,230),white,false,3.0)
    draw_rect(Rect2(L-29,GT,29,GB-GT),Color("#dbe5ed"))
    draw_rect(Rect2(R,GT,29,GB-GT),Color("#dbe5ed"))
    # Distinct rows visually resemble a tabletop football formation.
    for f in figures:
        var pos: Vector2 = f["pos"]
        var color := Color("#318bf4") if f["team"] == 0 else Color("#ef5554")
        draw_circle(pos+Vector2(3,7),24,Color(0,0,0,0.26))
        draw_circle(pos,24,Color("#ead9b3"))
        draw_circle(pos+Vector2(0,-3),19,color)
        draw_circle(pos+Vector2(-4,-8),8,Color("#ffe4bd"))
        draw_circle(pos+Vector2(-7,-9),1.9,Color("#223148"))
        draw_circle(pos+Vector2(-2,-9),1.9,Color("#223148"))
        draw_arc(pos,26,0,TAU,24,Color(1,1,1,0.35),2)
        if selected >= 0 and aiming and f["pos"] == figures[selected]["pos"]:
            draw_arc(pos,32,0,TAU,28,Color("#ffe27d"),3)
    if aiming and selected >= 0:
        var sp: Vector2 = figures[selected]["pos"]
        var pull := (aim_start-aim_now).limit_length(145)
        draw_line(sp,sp+pull*1.5,Color("#ffe17c"),5)
        draw_circle(sp+pull*1.5,8,Color("#ffe17c"))
    draw_circle(ball+Vector2(3,5),14,Color(0,0,0,0.22))
    draw_circle(ball,13,Color.WHITE)
    draw_circle(ball+Vector2(-3,-3),5,Color("#25344a"))
    draw_circle(ball+Vector2(6,4),3,Color("#25344a"))
    draw_rect(Rect2(0,0,1280,89),Color("#111c2d"))
    _label("СИНИЕ  %d : %d  КРАСНЫЕ" % [blue,red],Vector2(640,40),36)
    if mode == 0:
        var secs := int(ceil(remaining))
        _label("%02d:%02d" % [int(secs/60),secs%60],Vector2(640,77),25,Color("#ffe09c"))
    else:
        _label("ПЕРВЫЙ ДО 10 ГОЛОВ",Vector2(640,77),24,Color("#ffe09c"))
    if message_timer > 0:
        _label(message,Vector2(640,117),32,Color("#ffe27d"))
    if phase == 0:
        draw_rect(Rect2(260,159,760,445),Color("#102138"))
        _label("TOY FOOTBALL 0.4",Vector2(640,240),52,Color("#ffdf86"))
        draw_rect(Rect2(350,274,580,84),Color("#2b577e"))
        _label("ПРОТИВ БОТА" if opponent == 0 else "ДВА ИГРОКА",Vector2(640,328),33)
        draw_rect(Rect2(350,367,580,87),Color("#2b577e"))
        _label("4 МИНУТЫ" if mode == 0 else "ДО 10 ГОЛОВ",Vector2(640,423),33)
        draw_rect(Rect2(350,467,580,112),Color("#36a66a"))
        _label("ИГРАТЬ",Vector2(640,539),47)
    elif phase == 2:
        draw_rect(Rect2(268,214,744,290),Color("#102138"))
        var result := "НИЧЬЯ!" if blue == red else ("ПОБЕДА СИНИХ!" if blue > red else "ПОБЕДА КРАСНЫХ!")
        _label(result,Vector2(640,333),48,Color("#ffe08c"))
        _label("НАЖМИ ДЛЯ НОВОГО МАТЧА",Vector2(640,421),31)
    else:
        _label("ОТТЯНИ ФИГУРКУ И ОТПУСТИ — УДАР",Vector2(640,689),21,Color("#dbe9ef"))
