extends Node2D

const W := 1280.0
const H := 720.0
const L := 64.0
const R := 1216.0
const T := 100.0
const B := 616.0
const CY := 358.0
const BLUE := Color("48c8ff")
const RED := Color("ff6476")
const WHITE := Color("f6fbff")
var font: Font
var state := "menu"
var mode := 0
var half := 1
var clock := 150.0
var scores := [0, 0]
var players: Array = []
var selected := [3, 3]
var joy := [Vector2.ZERO, Vector2.ZERO]
var pointers := {}
var ball := Vector2(640, CY)
var ball_vel := Vector2.ZERO
var ball_holder := -1
var cooldown := 0.0
var bot_timer := 0.0
var goal_pause := 0.0
var toast := ""
var toast_timer := 0.0
var shot_power := [0.0, 0.0]
var last_touch_team := 0

func _ready() -> void:
 font = ThemeDB.fallback_font
 set_process(true)

func _team_side(t:int) -> float:
 return 1.0 if (t == 0) == (half == 1) else -1.0

func _start() -> void:
 scores = [0, 0]
 half = 1
 clock = 150.0
 state = "play"
 _reset()

func _reset() -> void:
 players.clear()
 for team in range(2):
  var side := _team_side(team)
  var spots := [Vector2(640.0-side*515.0,CY),Vector2(640.0-side*340.0,210),Vector2(640.0-side*340.0,506),Vector2(640.0-side*130.0,CY),Vector2(640.0-side*235.0,350)]
  for i in range(5):
   players.append({"team":team,"pos":spots[i],"home":spots[i],"face":Vector2(side,0),"number":i,"tackle":0.0})
 selected = [3,3]
 ball = Vector2(640,CY)
 ball_vel = Vector2.ZERO
 ball_holder = -1
 cooldown = 0.9
 goal_pause = 0.9
 joy = [Vector2.ZERO,Vector2.ZERO]
 pointers.clear()

func _index(t:int,i:int) -> int:
 return t*5+i

func _player(t:int,i:int) -> Dictionary:
 return players[_index(t,i)]

func _closest(t:int,where:Vector2,include_keeper:bool=false) -> int:
 var best := 1
 var dist := INF
 for i in range(5):
  if i == 0 and not include_keeper:
   continue
  var d:float = (_player(t,i)["pos"] as Vector2).distance_squared_to(where)
  if d < dist:
   dist = d
   best = i
 return best

func _process(delta:float) -> void:
 var dt:float = min(delta,0.045)
 toast_timer = max(0.0,toast_timer-dt)
 if state != "play":
  queue_redraw()
  return
 if goal_pause > 0:
  goal_pause -= dt
  queue_redraw()
  return
 clock -= dt
 if clock <= 0:
  if half == 1:
   state = "half"
  else:
   state = "end"
  pointers.clear()
  queue_redraw()
  return
 cooldown = max(0.0,cooldown-dt)
 bot_timer -= dt
 for t in range(2):
  if shot_power[t] > 0:
   shot_power[t] = min(1.0,shot_power[t]+dt*0.7)
 if mode == 0:
  _bot(dt)
 _move_players(dt)
 _move_ball(dt)
 queue_redraw()

func _move_players(dt:float) -> void:
 for t in range(2):
  var side := _team_side(t)
  for i in range(5):
   var p:Dictionary = _player(t,i)
   var pos:Vector2 = p["pos"]
   var direction := Vector2.ZERO
   if i == 0:
    # Keeper has limited movement and reaction, never teleports to the ball.
    var target_y:float = clamp(ball.y, CY-83,CY+83)
    if abs(pos.y-target_y)>14:
     direction.y = sign(target_y-pos.y)
    pos.y = move_toward(pos.y,target_y,118.0*dt)
    pos.x = 640.0-side*515.0
   else:
    if selected[t] == i:
     direction = joy[t]
    else:
     var target:Vector2 = p["home"]
     if ball_holder >= 0:
      var carrier:Dictionary = players[ball_holder]
      var carrier_team:int = carrier["team"]
      if carrier_team == t:
       target += Vector2(side*85.0, (-1.0 if i%2==0 else 1.0)*38.0)
      elif i == _closest(t,ball):
       target = ball - Vector2(side*22,0)
     elif i == _closest(t,ball):
      target = ball - Vector2(side*18,0)
     if pos.distance_to(target)>24:
      direction = pos.direction_to(target)*0.72
    if direction.length_squared()>1:
     direction = direction.normalized()
    if direction.length()>0.05:
     p["face"] = direction.normalized()
    pos += direction*205.0*dt
    pos.x = clamp(pos.x,L+23,R-23)
    pos.y = clamp(pos.y,T+23,B-23)
   p["pos"] = pos
 # Tackle: defenders must reach ball carrier; a tackle is not guaranteed.
 if ball_holder >= 0 and cooldown <= 0:
  var carrying:Dictionary = players[ball_holder]
  var carrier_team:int = carrying["team"]
  var carrier_pos:Vector2 = carrying["pos"]
  for t in range(2):
   if t == carrier_team:
    continue
   for i in range(1,5):
    var defender:Vector2 = _player(t,i)["pos"]
    if defender.distance_to(carrier_pos)<34:
     if joy[t].length()>0.15 and selected[t]==i or i==_closest(t,carrier_pos):
      ball_holder = _index(t,i)
      selected[t] = i
      cooldown = 0.65
      last_touch_team = t
      toast = "ОТБОР!"
      toast_timer = 0.45
      return

func _move_ball(dt:float) -> void:
 if ball_holder >= 0:
  var p:Dictionary = players[ball_holder]
  var face:Vector2 = p["face"]
  var pos:Vector2 = p["pos"]
  ball = pos+face*27.0
  ball_vel = Vector2.ZERO
 else:
  ball += ball_vel*dt
  ball_vel *= pow(0.984,dt*60.0)
  if ball_vel.length()<10:
   ball_vel = Vector2.ZERO
  if ball.y<T+10:
   ball.y=T+10
   ball_vel.y=abs(ball_vel.y)*0.74
  if ball.y>B-10:
   ball.y=B-10
   ball_vel.y=-abs(ball_vel.y)*0.74
  if ball.x<L or ball.x>R:
   if abs(ball.y-CY)<86:
    var scorer := 0 if ball.x>R else 1
    if _team_side(scorer)<0:
     scorer=1-scorer
    scores[scorer]+=1
    toast="ГОООЛ!"
    toast_timer=1.1
    _reset()
    goal_pause=1.1
    return
   ball.x=clamp(ball.x,L+11,R-11)
   ball_vel.x*=-0.65
  # Goalkeeper saves only balls in reach, with limited save window.
  for t in range(2):
   var keeper:Vector2 = _player(t,0)["pos"]
   if keeper.distance_to(ball)<29 and ball_vel.length()>40:
    ball_vel = (ball-keeper).normalized()*min(370.0,ball_vel.length()*0.63)
    cooldown=0.25
  if cooldown<=0:
   var nearest := -1
   var distance := 34.0
   for idx in range(players.size()):
    if idx%5==0:
     continue
    var d:float = (players[idx]["pos"] as Vector2).distance_to(ball)
    if d<distance:
     distance=d
     nearest=idx
   if nearest>=0:
    ball_holder=nearest
    last_touch_team=int(players[ball_holder]["team"])
    selected[last_touch_team]=ball_holder%5
    ball_vel=Vector2.ZERO

func _action(t:int,shoot:bool,power:float=0.5) -> void:
 if state!="play" or goal_pause>0:
  return
 if ball_holder<0 or int(players[ball_holder]["team"])!=t:
  selected[t]=_closest(t,ball)
  return
 var p:Dictionary = players[ball_holder]
 var side:=_team_side(t)
 var direction:Vector2 = p["face"]
 if direction.length()<0.1:
  direction=Vector2(side,0)
 if shoot:
  # Aim is controlled by joystick; forward is fallback, not a fixed line to goal.
  var stick:Vector2=joy[t]
  if stick.length()>0.22:
   direction=stick.normalized()
  else:
   direction=(direction+Vector2(side*0.3,0)).normalized()
  ball_vel=direction*(640.0+380.0*clamp(power,0.0,1.0))
  toast="УДАР!"
 else:
  var origin:Vector2=p["pos"]
  var best:=-1
  var best_score:=-INF
  for i in range(1,5):
   if _index(t,i)==ball_holder:
    continue
   var teammate:Vector2=_player(t,i)["pos"]
   var advance:float=(teammate.x-origin.x)*side
   var proximity:float=origin.distance_to(teammate)
   var value:float=advance*0.7-proximity*0.2
   if value>best_score:
    best_score=value
    best=i
  if best>=0:
   var dest:Vector2=_player(t,best)["pos"]
   direction=(dest-origin).normalized()
  ball_vel=direction*535.0
  toast="ПАС!"
 toast_timer=0.4
 ball=(p["pos"] as Vector2)+direction*32
 ball_holder=-1
 cooldown=0.25
 last_touch_team=t

func _bot(dt:float) -> void:
 if mode!=0:
  return
 var t:=1
 if ball_holder>=0 and int(players[ball_holder]["team"])==t:
  selected[t]=ball_holder%5
  var p:Vector2=players[ball_holder]["pos"]
  var side:=_team_side(t)
  var target:=Vector2(640+side*550,CY)
  var toward:Vector2=p.direction_to(target)
  if abs(p.y-CY)>95:
   toward=(toward+Vector2(0,sign(CY-p.y))*0.45).normalized()
  joy[t]=toward
  if bot_timer<=0:
   if abs(p.x-(640+side*510))<315:
    _action(t,true,0.35)
    bot_timer=1.2
   elif p.x*side > (640+side*40)*side and randi()%4==0:
    _action(t,false)
    bot_timer=1.0
 else:
  selected[t]=_closest(t,ball)
  var pp:Vector2=_player(t,selected[t])["pos"]
  joy[t]=pp.direction_to(ball) if pp.distance_to(ball)>12 else Vector2.ZERO

func _draw() -> void:
 var size:=get_viewport_rect().size
 var s:float=min(size.x/W,size.y/H)
 var offset:Vector2=(size-Vector2(W,H)*s)*0.5
 draw_set_transform(offset,0,Vector2.ONE*s)
 draw_rect(Rect2(0,0,W,H),Color("0c1829"))
 if state=="menu":
  _menu()
 else:
  _field()
  _hud()
  if state=="play":
   _controls()
  if state=="half" or state=="end":
   draw_rect(Rect2(0,0,W,H),Color(0,0,0,0.77))
   _txt("ПЕРЕРЫВ" if state=="half" else "МАТЧ ОКОНЧЕН",Vector2(470,270),46,WHITE)
   _txt("%d : %d" % [scores[0],scores[1]],Vector2(557,356),54,WHITE)
   _button(Rect2(410,412,460,82),"ВТОРОЙ ТАЙМ" if state=="half" else "ГЛАВНОЕ МЕНЮ",Color("237eb5"))
 draw_set_transform(Vector2.ZERO,0,Vector2.ONE)

func _txt(value:String,at:Vector2,size:int,color:Color=WHITE) -> void:
 draw_string(font,at,value,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _button(rect:Rect2,title:String,color:Color) -> void:
 draw_rect(rect,color)
 draw_rect(rect,WHITE,false,2)
 var width:float=font.get_string_size(title,HORIZONTAL_ALIGNMENT_LEFT,-1,27).x
 _txt(title,Vector2(rect.position.x+(rect.size.x-width)*0.5,rect.position.y+rect.size.y*0.63),27)

func _menu() -> void:
 draw_rect(Rect2(0,0,W,H),Color("102a3b"))
 for i in range(9):
  draw_line(Vector2(i*160,0),Vector2(i*160,H),Color("193c4c"),1)
 _txt("TOY FOOTBALL",Vector2(385,150),65,Color("f6d17a"))
 _txt("АРКАДНЫЙ ФУТБОЛ  •  2 ТАЙМА ПО 2:30",Vector2(346,214),26)
 _button(Rect2(350,276,580,105),"ПРОТИВ БОТА",Color("197eae"))
 _button(Rect2(350,408,580,105),"ДВА ИГРОКА",Color("9c4b75"))
 _txt("Джойстик — движение   •   Пас   •   Удар   •   Смена",Vector2(295,593),23,Color("b8d5e7"))

func _field() -> void:
 draw_rect(Rect2(L-12,T-12,R-L+24,B-T+24),Color("684a30"))
 draw_rect(Rect2(L,T,R-L,B-T),Color("20834e"))
 for i in range(12):
  if i%2==0:
   draw_rect(Rect2(L+i*(R-L)/12.0,T,(R-L)/12.0,B-T),Color("29975a"))
 draw_rect(Rect2(L,T,R-L,B-T),WHITE,false,3)
 draw_line(Vector2(640,T),Vector2(640,B),WHITE,3)
 draw_arc(Vector2(640,CY),74,0,TAU,64,WHITE,3)
 draw_circle(Vector2(640,CY),5,WHITE)
 draw_rect(Rect2(L,CY-145,165,290),WHITE,false,3)
 draw_rect(Rect2(R-165,CY-145,165,290),WHITE,false,3)
 draw_rect(Rect2(L-22,CY-85,22,170),Color("c6e9fa"),false,4)
 draw_rect(Rect2(R,CY-85,22,170),Color("c6e9fa"),false,4)
 for idx in range(players.size()):
  var p:Dictionary=players[idx]
  var pos:Vector2=p["pos"]
  var color:Color=BLUE if int(p["team"])==0 else RED
  draw_circle(pos+Vector2(3,6),20,Color(0,0,0,0.3))
  draw_circle(pos,18,color)
  draw_arc(pos,19,0,TAU,24,WHITE,2)
  if idx%5==0:
   _txt("G",pos+Vector2(-8,7),20,Color("122438"))
  else:
   _txt(str(idx%5),pos+Vector2(-6,7),20,Color("122438"))
  if selected[int(p["team"])]==idx%5 and (mode==1 or int(p["team"])==0):
   draw_arc(pos,24,0,TAU,32,Color("ffe38b"),3)
  if ball_holder==idx:
   draw_circle(pos+Vector2(0,-24),5,Color("ffe38b"))
 draw_circle(ball+Vector2(3,5),12,Color(0,0,0,0.3))
 draw_circle(ball,11,WHITE)
 draw_circle(ball+Vector2(-3,-3),4,Color("233b50"))

func _hud() -> void:
 draw_rect(Rect2(380,8,520,77),Color("0b2335"))
 _txt("СИНИЕ",Vector2(398,40),23,BLUE)
 _txt("%d : %d" % [scores[0],scores[1]],Vector2(565,45),40)
 _txt("КРАСНЫЕ",Vector2(747,40),23,RED)
 var secs:int=int(ceil(clock))
 _txt("%d ТАЙМ   %02d:%02d" % [half,int(secs/60.0),secs%60],Vector2(538,76),20)
 if toast_timer>0:
  _txt(toast,Vector2(550,130),32,Color("ffe38b"))

func _controls() -> void:
 _joystick(Vector2(90,645),0)
 _circle_button(Vector2(1003,665),"СМЕНА",Color("49647c"),36)
 _circle_button(Vector2(1094,665),"ПАС",Color("368fd0"),36)
 _circle_button(Vector2(1191,665),"УДАР",Color("e7a73b"),36)
 if mode==1:
  _joystick(Vector2(1190,68),1)
  _circle_button(Vector2(1000,68),"СМЕНА",Color("49647c"),30)
  _circle_button(Vector2(1075,68),"ПАС",Color("368fd0"),30)
  _circle_button(Vector2(1140,68),"УДАР",Color("e7a73b"),30)

func _joystick(center:Vector2,t:int) -> void:
 draw_circle(center,57,Color(0.08,0.17,0.25,0.78))
 draw_arc(center,57,0,TAU,40,BLUE if t==0 else RED,2)
 draw_circle(center+joy[t]*29,24,Color("d4eaf8"))

func _circle_button(center:Vector2,title:String,color:Color,radius:float) -> void:
 draw_circle(center,radius,color)
 draw_arc(center,radius,0,TAU,36,Color("10283d"),2)
 var w:float=font.get_string_size(title,HORIZONTAL_ALIGNMENT_LEFT,-1,16).x
 _txt(title,center+Vector2(-w*0.5,6),16)

func _screen_to_game(screen:Vector2) -> Vector2:
 var size:=get_viewport_rect().size
 var s:float=min(size.x/W,size.y/H)
 var offset:Vector2=(size-Vector2(W,H)*s)*0.5
 return (screen-offset)/s

func _input(event:InputEvent) -> void:
 if event is InputEventScreenTouch:
  var p:=_screen_to_game(event.position)
  if event.pressed:
   _press(event.index,p)
  else:
   _release(event.index,p)
 elif event is InputEventScreenDrag:
  _drag(event.index,_screen_to_game(event.position))
 elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
  var p:=_screen_to_game(event.position)
  if event.pressed:
   _press(99,p)
  else:
   _release(99,p)
 elif event is InputEventMouseMotion and pointers.has(99):
  _drag(99,_screen_to_game(event.position))

func _press(id:int,p:Vector2) -> void:
 if state=="menu":
  if Rect2(350,276,580,105).has_point(p):
   mode=0
   _start()
  elif Rect2(350,408,580,105).has_point(p):
   mode=1
   _start()
  return
 if state=="half" or state=="end":
  if Rect2(410,412,460,82).has_point(p):
   if state=="half":
    half=2
    clock=150.0
    state="play"
    _reset()
   else:
    state="menu"
  return
 if state!="play":
  return
 if p.distance_to(Vector2(90,645))<105:
  pointers[id]={"type":"joy","team":0}
  _drag(id,p)
  return
 if mode==1 and p.distance_to(Vector2(1190,68))<65:
  pointers[id]={"type":"joy","team":1}
  _drag(id,p)
  return
 var t:=0
 var action:=""
 if p.distance_to(Vector2(1003,665))<41: action="switch"
 elif p.distance_to(Vector2(1094,665))<41: action="pass"
 elif p.distance_to(Vector2(1191,665))<41: action="shoot"
 elif mode==1:
  t=1
  if p.distance_to(Vector2(1000,68))<34: action="switch"
  elif p.distance_to(Vector2(1075,68))<34: action="pass"
  elif p.distance_to(Vector2(1140,68))<34: action="shoot"
 if action=="switch":
  _switch(t)
 elif action=="pass":
  _action(t,false)
 elif action=="shoot":
  shot_power[t]=0.01
  pointers[id]={"type":"shoot","team":t}

func _drag(id:int,p:Vector2) -> void:
 if not pointers.has(id):
  return
 var pointer:Dictionary=pointers[id]
 if pointer["type"]=="joy":
  var t:int=pointer["team"]
  var center:=Vector2(90,645) if t==0 else Vector2(1190,68)
  joy[t]=(p-center).limit_length(54)/54.0

func _release(id:int,_p:Vector2) -> void:
 if not pointers.has(id):
  return
 var pointer:Dictionary=pointers[id]
 var t:int=pointer["team"]
 if pointer["type"]=="joy":
  joy[t]=Vector2.ZERO
 elif pointer["type"]=="shoot":
  _action(t,true,shot_power[t])
  shot_power[t]=0.0
 pointers.erase(id)

func _switch(t:int) -> void:
 if ball_holder>=0 and int(players[ball_holder]["team"])==t:
  selected[t]=ball_holder%5
  return
 var current:int=selected[t]
 var best:int=_closest(t,ball)
 if best==current:
  best=1+(current%4)
 selected[t]=best
